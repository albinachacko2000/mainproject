
<?php
session_start();
include("config.php");
if(isset($_POST["btnsubmit"]))
{
	$UserName=$_POST['txt_email'];
	$Pasword=$_POST['txt_pwd'];
	$p=md5($_POST['txt_pwd']);
	echo $p;
   
		$result=mysqli_query($con,"SELECT * from tbl_login where Email='$UserName' and active='0' and Pwd='$p' or Pwd='$Pasword'");
  		$row=mysqli_fetch_array($result);
  		if($row>0)
		{
			$role=$row["role"];
			$active=$row["active"];
			if($role==2)
			{
				if($active==1){
					echo "<script>alert('Your are not permitted to axcess your account.Please Contact the Admin');window.location='index.php'</script>";	}
					else{
		    $_SESSION["lid"]=$row["lid"];
			$_SESSION["Email"]=$row["Email"];
			header("location:../Customer/index.php");}
			}
			else if($role==1)
			{
				$_SESSION["lid"]=$row["lid"];
			header("location:../Admin/index.php");
			}
			else if($role==3)
			{
				
				$_SESSION["lid"]=$row["lid"];
				header("location:../DeliveryBoy/index.php");
				

			}

			else 
			{
				echo "<script>alert('Invalid Email/Password!!');window.location='index.php'</script>";	
			}

        }
        else
        {
            
		echo "<script>alert('Invalid Email/Password!!');window.location='index.php'</script>";	
		}
		
}
?>
