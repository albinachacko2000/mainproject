// function registerValid(){
//             var isValid=true;
//             var nameCityPattern =  /^[a-zA-Z]+$/;
//             var pwdPattern=/^(?=.*\d)(?=.*[A-Z]).{6,}/;
//             var contactPattern = /^(\+91[\-\s]?)?[0]?(91)?[789]\d{9}$/;
//             var emailPattern = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
//             var validFirstname = document.getElementById("name").value;
//             var validLastname = document.getElementById("address").value;
//             var validCity = document.getElementById("city").value;
//             var validContact = document.getElementById("mobile").value;
//             var validEmail = document.getElementById("email").value;
//             var validPassword1 = document.getElementById("password1").value;
//             var validPassword2 = document.getElementById("password2").value;

//            //firstName validation on buttonClick
//             if(validFirstname==null || validFirstname==""){
//                 document.getElementById("fnameValidate").innerHTML="First Name Required";
//                 isValid=false;
//             }
//             else if(!validFirstname.match(nameCityPattern)){
//                 document.getElementById("fnameValidate").innerHTML="Only characters are acceptable";
//                 isValid=false;
//             }
// 			//lastName validation on buttonClick
//             if(validLastname==null || validLastname==""){
//                 document.getElementById("lnameValidate").innerHTML="Address Required";
//                 isValid=false;
//             }
//             else if(!validLastname.match(nameCityPattern)){
//                 document.getElementById("lnameValidate").innerHTML="Only characters are acceptable";
//                 isValid=false;
//             }

//             //city validation on buttonClick
//             if(validCity==null || validCity==""){
//                 document.getElementById("cityValidate").innerHTML="City Required";
//                 isValid=false;
//             }
//             else if(!validCity.match(nameCityPattern)){
//                 document.getElementById("cityValidate").innerHTML="Invalid City";
//                 isValid=false;
//             }

//             //contact validation on buttonClick
//             if(validContact==null || validContact==""){
//                 document.getElementById("contactValidate").innerHTML="Contact Required";
//                 isValid=false;
//             }
//             else if(!validContact.match(contactPattern)){
//                 document.getElementById("contactValidate").innerHTML="Invalid contact number";
//                 isValid=false;
//             }
// 			//email validation on buttonClick
//             if(validEmail==null || validEmail==""){
//                 document.getElementById("emailValidate").innerHTML="Email Required";
//                 isValid=false;
//             }
//             else if(!validEmail.match(emailPattern)){
//                 document.getElementById("emailValidate").innerHTML="Invalid email";
//                 isValid=false;
//             }

//             //password validation on buttonClick
//             if(validPassword1==null || validPassword1==""){
//                 document.getElementById("passwordValidate").innerHTML="Password Required";
//                 isValid=false;
//             }
//             else if(!validPassword1.match(pwdPattern)){
//                 alert("Password should have atleast 8 characters with one alphaneumeric, one uppercase and one lowercase");
//                 isValid=false;
//             }
//         }
// 		function fnameValidate(){
//          var firstname = document.getElementById("name").value;
//          var pattern =  /^[a-zA-Z]+$/;
//          isValid=true;
//          if(firstname.match(pattern)){
//             document.getElementById("fnameValidate").innerHTML="";
//          }
//          else if(!firstname){
//             document.getElementById("fnameValidate").innerHTML="First Name Required";
//             isValid=false;
//          }
//          else{
//             document.getElementById("fnameValidate").innerHTML="Only characters are acceptable";
//             isValid=false;
//          }
//          return isValid;
//       }
	  function emailValidate(){
          alert(hi);
         var email = document.getElementById("loginEmail").value;
         var pattern = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
         isValid=true;
         if(email.match(pattern)){
            document.getElementById("emailValidate").innerHTML="";
          }
          else if(!email){
            document.getElementById("emailValidate").innerHTML="Email Required";
            isValid=false;
         }
          else{
            document.getElementById("emailValidate").innerHTML="Invalid email";
            isValid=false;
          }
          return isValid;
      }
// 	  function cnoValidate(){
//          var cno = document.getElementById("mobile").value;
//          var pattern = /^(\+91[\-\s]?)?[0]?(91)?[789]\d{9}$/;
//          isValid=true;
//          if(cno.match(pattern)){
//             document.getElementById("contactValidate").innerHTML="";
//          }
//          else if(!cno){
//             document.getElementById("contactValidate").innerHTML="Number required";
//             isValid=false;
//          }
//          else{
//             document.getElementById("contactValidate").innerHTML="Invalid Contact Number";
//             isValid=false;
//          }
//          return isValid;
         
//       }
	  
// //Login button click
// function loginValid(){
//             var loginEmail = document.getElementById("loginEmail").value;
//             var loginEmailPattern = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
//             isValid=true;
//             if(loginEmail.match(loginEmailPattern)){
//                 document.getElementById("validateEmail").innerHTML="";
//             }
//             else if(!loginEmail){
//                 document.getElementById("validateEmail").innerHTML="Email Required";
//                 isValid=false;
//             }
//             else{
//                 document.getElementById("validateEmail").innerHTML="Invalid email";
//                 isValid=false;
//             }
// 			var loginPassword = document.getElementById("loginPassword").value;
//             var loginPasswordPattern=/^(?=.*\d)(?=.*[A-Z]).{6,}/;
//             isValid=true;
//             if(loginPassword.match(loginPasswordPattern)){
//                 document.getElementById("validatePassword").innerHTML="";
//             }
//             else if(!loginPassword){
//                 document.getElementById("validatePassword").innerHTML="Password Required";
//                 isValid=false;
//             }
//             else{
//                 alert("Password should have atleast 8 characters with one alphaneumeric, one uppercase and one lowercase");
//                 isValid=false;
//             }
//             return isValid;
//         }
// function loginEmailValidate(){
//           var loginEmail = document.getElementById("loginEmail").value;
//             var loginEmailPattern = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
//             isValid=true;
//             if(loginEmail.match(loginEmailPattern)){
//                 document.getElementById("validateEmail").innerHTML="";
//             }
//             else if(!loginEmail){
//                 document.getElementById("validateEmail").innerHTML="Email Required";
//                isValid=false;
//                      }
//             else{
//                document.getElementById("validateEmail").innerHTML="Invalid email";
//                isValid=false;
//            }
//             return isValid;
//       }

//       function loginPasswordValidate(){
//          var loginPassword = document.getElementById("loginPassword").value;
//             var loginPasswordPattern=/^(?=.*\d)(?=.*[A-Z]).{6,}/;
//               isValid=true;
//             if(loginPassword.match(loginPasswordPattern)){
//                 document.getElementById("validatePassword").innerHTML="";
//             }
//             else if(!loginPassword){
//                 document.getElementById("validatePassword").innerHTML="Password Required";
//                 isValid=false;
//             }
//             else{
//                 isValid=false;
//            }
//            return isValid;
//       }
