<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{
	$email=$_POST['txt_email'];
    $password=$_POST['txt_pwd'];
    $p=md5($_POST['txt_pwd']);
    $password1=$_POST['txt_pd'];
    $Name=$_POST['name'];
    $Mobile=$_POST['mobile'];
   
   
    $Address=$_POST['address'];
    $Place=$_POST['city'];
    $Pincode=$_POST['pin'];
    $s=mysqli_query($con,"SELECT count(*) as count FROM tbl_login WHERE Email='$email' and role='2'");
  		$display=mysqli_fetch_array($s);
  		if($display['count']>0)
		{
		echo "<script>alert('This email is already exist');window.location='index.php'</script>";	
		}
		else
		{
    
    if($password!=$password1)
    {
      echo "<script>alert('Password are not match');window.location='index.php'</script>";
    }
		else
    {
      $sql1=mysqli_query($con,"INSERT INTO tbl_register(name,phone,address,place,pincode,rstatus) VALUES('$Name','$Mobile','$Address','$Place','$Pincode','0')");
      $result=mysqli_query($con,"SELECT rid from tbl_register where phone=$Mobile");
  		$row=mysqli_fetch_array($result);
  	if($row>0)
		{
			$rid=$row["rid"];
      $sql=mysqli_query($con,"INSERT INTO tbl_login(rid,Email,Pwd,role,lstatus,active)VALUES('$rid','$email','$p',2,0,0)");
      $lid=mysqli_insert_id($con);
      $sql2=mysqli_query($con,"INSERT INTO tbl_deliveryaddress(lid,name,phone,address,place,dstatus)VALUES('$lid','$Name','$Mobile','$Address','$Place','0')");
        }
    else
    {
      echo "<script>alert('Error');window.location='index.php'</script>";
    }   
      
		

if($sql && $sql1 && $sql2)
  {
	 
echo "<script>alert(' Signup Successfully!!');window.location='index.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='index.php'</script>";
  }
}
}
}
?>
