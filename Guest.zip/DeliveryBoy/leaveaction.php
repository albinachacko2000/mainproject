
<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{
    $lid=$_SESSION['lid'];
    $todate=$_POST['todate'];
    $fromdate=$_POST['fromdate'];
    $reason=$_POST['reason'];
   
    
    $sql=mysqli_query($con,"INSERT INTO tbl_leave(lid,todate,fromdate,reason,lestatus) VALUES('$lid','$todate','$fromdate','$reason','Pending')");

    
    
    if($sql)
      {
       $_SESSION['status'] = "Registered Successfully";
       
       header('Location: leave.php');
      }
    else
      {
        $_SESSION['status']="Data not inserted/Already Exit";
       
       header('Location: leave.php');
    
      }
    }
    
    
  	
?>
