<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmitt"]))
{
	$email=$_POST['txt_email1'];
    $password=$_POST['txt_pwd1'];
    $p=md5($_POST['txt_pwd1']);
    $password1=$_POST['txt_pd1'];
    $Name=$_POST['name1'];
    $Mobile=$_POST['mobile1'];
   
   
    
    $Place=$_POST['city1'];
    $Pincode=$_POST['pin1'];
    $s=mysqli_query($con,"SELECT count(*) as count FROM tbl_login WHERE Email='$email' and role='4'");
  		$display=mysqli_fetch_array($s);
  		if($display['count']>0)
		{
		echo "<script>alert('This email is already exist');window.location='index.php'</script>";	
		}
		else
		{
    
    if($password!=$password1)
    {
      echo "<script>alert('Password are not match');window.location='index.php'</script>";
    }
		else
    {
      $sql1=mysqli_query($con,"INSERT INTO tbl_seller(slname,phone,place,pin,slstatus) VALUES('$Name','$Mobile','$Place','$Pincode','0')");
      $lid=mysqli_insert_id($con);
     
      $sql=mysqli_query($con,"INSERT INTO tbl_login(rid,Email,Pwd,role,lstatus,active)VALUES('$lid','$email','$p',4,0,0)");
      
        
    

if($sql && $sql1)
  {
	 
echo "<script>alert(' Signup Successfully!!');window.location='index.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='index.php'</script>";
  }
}
}
}
?>
