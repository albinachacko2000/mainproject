<?php
include("config.php");
session_start();

$lid=$_SESSION['lid'];
if(isset($_POST["button"]))
{
  $cname=$_POST['nname'];
  $cnumber=$_POST['nnumber'];
  $scode=$_POST['ssecuritycode'];
  $edate=$_POST['eexpiration'];
  
  //$total=$_POST['total'];
  $sql1=mysqli_query($con,"SELECT * FROM tbl_card WHERE lid=$lid");
  $sql=mysqli_query($con,"SELECT * FROM tbl_payment WHERE lid=$lid");
  while($row=mysqli_fetch_array($sql1)){
    $amount=$row['amount']; 
					while($row=mysqli_fetch_array($sql)){
						
						$price=$row['price'];
                    }}
                    
                        $total=$amount-$price;
                     
                        $result= $sql=mysqli_query($con,"UPDATE tbl_cart SET cstatus='1' where lid=$lid");

  $result1= $sql=mysqli_query($con,"UPDATE tbl_payment SET paytype='Online',pstatus='yes' where lid=$lid");
  $result2= $sql=mysqli_query($con,"UPDATE tbl_card SET amount=$total where cnumber=$cnumber");
  if($result1 && $result2 && $result)
  {
  echo "<script>alert('payment successfully');window.location='index.php'</script>";	
       
  }
    }?>