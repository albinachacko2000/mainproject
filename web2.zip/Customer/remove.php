<?php

include("config.php");
?>

<form action="" method="POST">

<div class="container" style="margin-left:250px;">
<?php
if(isset($_GET['id']))
{
 $id=$_GET['id'];
 $result1=mysqli_query($con,"SELECT * from tbl_cart where cartid='$id' ");
    $row=mysqli_fetch_array($result1);
    if($row>0){

      $sid=$row['stockid'];
      $pqua=$row['qty'];
      echo $pqua;
    $result2=mysqli_query($con,"SELECT * from tbl_stock where stockid='$sid' ");
    $row2=mysqli_fetch_array($result2);
    
  if($row2>0)
  {
    $astock=$row2['astock']+$pqua;
    $stockout=$row2['stockout']-$pqua;
    
          $sql = mysqli_query($con,"UPDATE tbl_stock SET astock='$astock',stockout='$stockout' WHERE stockid='$sid'");
  $result=mysqli_query($con,"UPDATE tbl_cart SET cstatus='1' where cartid=$id");
  } 
}}
if($result)
{
    header('Location: checkout.php');
}
?>