<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <title>Login</title>
    <style>
        body {
            background-color: white;
        }

        .navbar {
            overflow: hidden;
            background-color:#1accfd;
            position: absolute;
            width: 100%;
            left: 0px;
            top: 0px;
        }


        .navbar a {
            float: right;
            color: white;
            padding-top: 30px;
            margin-right: 50px;
            text-decoration: none;
            font-family: 'Itim';
        }

        .navbar a.left {
            float: left;
            padding: 0%;
            padding-left: 25px;
        }

        .navbar a:hover {
            color: rgb(185, 185, 185);
        }

        .ticket {
            position: absolute;
            width: 561px;
            height: 497px;
            left: 807px;
            top: 163px;
        }

        table {
            position: absolute;
            left: 550px;
            top: 200px;
        }

        table label {
            font-family: 'Poppins';
            font-style: normal;
            font-weight: 700;
            font-size: 23px;
            line-height: 48px;
        }

        input:not([type=submit]) {
            box-sizing: border-box;
            background: white;
            border: 2px solid #757070;
            border-radius: 9px;
            padding: 10px;
            width: 300px;
            height: 45px;
        }

        input[type="submit"] {
            position: absolute;
            background: #1accfd;
            top: 210px;
            left:195px;
            height: 40px;
            width: 90px;
            border-radius: 20px;
            color: white;
            border: none;
            font-family: 'Poppins';
            /* font-weight: bold; */

        }

        input[type="submit"]:hover {
            background-color: #000000;
            cursor: pointer;
        }

        ::placeholder {
            font-family: 'Poppins';
            padding-left: 8px;
            font-weight: 700;
        }
    </style>
</head>

<body>
    <div class="navbar">
        
        <a class="left" href="  Customer/index.php"><img src="videoimg2.png" alt="FreshShop" width="100" height="50"><sup>FreshShop</sup></a>
    </div>
    <form action="actioncpd.php" method="POST">
        <table>
            <tr>
                <td><label for="Email">Change password</label></td>
            </tr>
            <tr>
                <td><input type="password" name="pd" placeholder="Enter your Old Password here"  title="Please enter a valid Email address"></td>
            </tr>
            <tr>
                <td><input type="password" name="npd" placeholder="Enter your New Password here" id="password" title="Please enter a valid Email address"></td>
               <td> <span id="pss" style="color: red;"></span></td>
              
              <style>
                                                 /* The message box is shown when the user clicks on the password field */
                                                    #message {
                                                    display:none;
                                                    background:#fff;
                                                    color: #000;
                                                    position: relative;
                                                    padding: 20px;
                                                    margin-top: 10px;
                                                    }
                                                                        #message p {
                                                    padding: 1px 35px;
                                                    font-size: 14px;
                                                    }
                                                    /* Add a green text color and a checkmark when the requirements are right */
                                                    .valid {
                                                    color: green;
                                                    }

                                                    .valid:before {
                                                    position: relative;
                                                    left: -25px;
                                                    content: "✔";
                                                    }

                                                    /* Add a red text color and an "x" when the requirements are wrong */
                                                    .invalid {
                                                    color: red;
                                                    }

                                                    .invalid:before {
                                                    position: relative;
                                                    left: -25px;
                                                    content: "✖";
                                                    }
                                                    </style>
                                                <div id="message">
<!--                                                    <h4 style="color:rgb(249, 164, 61) ;">Password must contain the following:</h4>-->
                                                        <p id="letter" class="invalid">A lowercase letter</p>
                                                        <p id="capital" class="invalid">A capital (uppercase) letter</p>
                                                        <p id="number" class="invalid">A number</p>
                                                        <p id="length" class="invalid">Minimum 8 characters</b></p>
                                                     </div>
                                                <script>
                                        var myInput = document.getElementById("password");
                                        var letter = document.getElementById("letter");
                                        var capital = document.getElementById("capital");
                                        var number = document.getElementById("number");
                                        var length = document.getElementById("length");
                                        myInput.onfocus = function() {
                                        document.getElementById("message").style.display = "block";
                                        }
                                        myInput.onblur = function() {
                                        document.getElementById("message").style.display = "none";
                                        }
                                        // When the user starts to type something inside the password field
                                        myInput.onkeyup = function() {
                                        // Validate lowercase letters
                                        var lowerCaseLetters = /[a-z]/g;
                                        if(myInput.value.match(lowerCaseLetters)) {
                                            letter.classList.remove("invalid");
                                            letter.classList.add("valid");
                                        } else {
                                            letter.classList.remove("valid");
                                            letter.classList.add("invalid");
                                        }

                                        // Validate capital letters
                                        var upperCaseLetters = /[A-Z]/g;
                                        if(myInput.value.match(upperCaseLetters)) {
                                            capital.classList.remove("invalid");
                                            capital.classList.add("valid");
                                        } else {
                                            capital.classList.remove("valid");
                                            capital.classList.add("invalid");
                                        }

                                        // Validate numbers
                                        var numbers = /[0-9]/g;
                                        if(myInput.value.match(numbers)) {
                                            number.classList.remove("invalid");
                                            number.classList.add("valid");
                                        } else {
                                            number.classList.remove("valid");
                                            number.classList.add("invalid");
                                        }

                                        // Validate length
                                        if(myInput.value.length >= 8) {
                                            length.classList.remove("invalid");
                                            length.classList.add("valid");
                                        } else {
                                            length.classList.remove("valid");
                                            length.classList.add("invalid");
                                        }
                                        }
                                    </script>
            </tr>
            <tr>
                <td><input type="password" name="cpd" placeholder="Confirm Password" id="cpassword" onkeyup="return  Password1()"  title="Please enter a valid Email address"></td>
                <td> <span id="pass2" style="color: red;"></span></td>
                <script>
                                        function Password1()
      {
        var pass1=document.getElementById('password').value;
        var pass2=document.getElementById('cpassword').value;
       if(!pass1.match(pass2))
       {
         console.log(pass2);
         document.getElementById('pass2').innerHTML="Password must match";  
         document.getElementById('password').value = pass;
         document.getElementById('cpassword').style.color = "red";
         return false;  
       }
       else
       {
          console.log(pass1, "Green");
          document.getElementById('password').innerHTML=" ";
         document.getElementById('cpassword').style.color = "green";
		 document.getElementById('pass2').innerHTML="";  
          //return true;
        }
      }
                                        </script>
            </tr>
            <tr>
                <td><input type="submit" name="btnsubmit" value="Submit"></td>
            </tr>
        </table>
    </form>
</body>

</html>