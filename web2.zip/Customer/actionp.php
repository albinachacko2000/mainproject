
<?php
include("config.php");
session_start();

$lid=$_SESSION['lid'];
if(isset($_POST["btnsubmit"]))
{
  $did=$_POST['did'];
  $result=mysqli_query($con,"UPDATE tbl_deliveryaddress SET dstatus='1' where did=$did");
  header("location:checkout.php");
    
    }
    if(isset($_POST["submit"]))
{
  $did=$_POST['daddress'];
  $total=$_POST['total'];
 
  $result1= $sql=mysqli_query($con,"INSERT INTO tbl_payment(lid,did,price,pstatus)VALUES('$lid','$did','$total','no')");
  header("location:payment.php");
    }
    
    
  	
?>
