<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<body>
<?php session_start();
 $r= $_SESSION['lid'];
 if($r!="")
 {

?>
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>FreshShop an Ecommerce Category Bootstrap Responsive Web Template | Home :: w3layouts</title>
	<!--/tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Grocery Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--//tags -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/font-awesome.css" rel="stylesheet">
	<!--pop-up-box-->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
	<!--//pop-up-box-->
	<!-- price range -->
	<link rel="stylesheet" type="text/css" href="css/jquery-ui1.css">
	<!-- fonts -->
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
	<style>
		.button1:hover{
			background-color:black;
			transition:0.7s;
		}
	</style>
	
</head>


	<!-- top-header -->
	<div class="header-most-top">
		<p>Grocery Offer Zone Top Deals & Discounts</p>
	</div>
	<!-- //top-header -->
	<!-- header-bot-->
	<div class="header-bot">
		<div class="header-bot_inner_wthreeinfo_header_mid">
			<!-- header-bot-->
			<div class="col-md-4 logo_agile">
				<h1>
					<a href="index.html">
						<span>F</span>resh
						<span>S</span>hop
						<img src="images/logo2.png" alt=" ">
					</a>
				</h1>
			</div>
			<!-- header-bot -->
			<div class="col-md-8 header">
				<!-- header lists -->
				
				<!-- //header lists -->
				<!-- search -->
				<div class="agileits_search">
					<form action="#" method="post">
						<input name="Search" type="search" placeholder="How can we help you today?" required="">
						<button type="submit" class="btn btn-default" aria-label="Left Align">
							<span class="fa fa-search" aria-hidden="true"> </span>
						</button>
					</form>
				</div>
				<!-- //search -->
				<!-- cart details -->
				<div class="top_nav_right">
					<div class="wthreecartaits wthreecartaits2 cart cart box_1"> 
					<a href="checkout.php"style="color:white;"><img src="images/d1.png" width="50px"></a></div>
					<!-- <div class="wthreecartaits wthreecartaits2 cart cart box_1">
						<form action="#" method="post" class="last">
							<input type="hidden" name="cmd" value="_cart">
							<input type="hidden" name="display" value="1">
							<button class="w3view-cart" type="submit" name="submit" value="">
								<i class="fa fa-cart-arrow-down" aria-hidden="true"></i>
							</button>
						</form>
					</div> -->
					
				</div>

				<!-- //cart details -->
				<div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<!-- shop locator (popup) -->
	<!-- Button trigger modal(shop-locator) -->
	<!-- //shop locator (popup) -->
	<!-- signin Model -->
	<!-- Modal1 -->
	<div class="modal fade" id="myModal1" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body modal-body-sub_agile">
					<div class="main-mailposi">
						<span class="fa fa-envelope-o" aria-hidden="true"></span>
					</div>
					<div class="modal_body_left modal_body_left1">
						<h3 class="agileinfo_sign">Sign In </h3>
						<p>
							Sign In now, Let's start your Fresh Shop. Don't have an account?
							<a href="#" data-toggle="modal" data-target="#myModal2">
								Sign Up Now</a>
						</p>
						<form action="loginnaction.php" method="post">
							<div class="styled-input agile-styled-input-top">
								<input type="text" placeholder="Email" name="txt_email" required="">
							</div>
							<div class="styled-input">
								<input type="password" placeholder="Password" name="txt_pwd" required="">
							</div>
							<input type="submit" name="btnsubmit" value="Sign In">
						</form>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			<!-- //Modal content-->
		</div>
	</div>
	<!-- //Modal1 -->
	<!-- //signin Model -->
	<!-- signup Model -->
	<!-- Modal2 -->
	<div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body modal-body-sub_agile">
					<div class="main-mailposi">
						<span class="fa fa-envelope-o" aria-hidden="true"></span>
					</div>
					<div class="modal_body_left modal_body_left1">
						<h3 class="agileinfo_sign">Sign Up</h3>
						<p>
							Come join the Fresh Shop! Let's set up your Account.
						</p>
						<form action="actionreg.php" method="post">
							<div class="styled-input agile-styled-input-top">
								<input type="text" placeholder="Name" name="name" required="">
							</div>
							<div class="styled-input agile-styled-input-top">
								<input type="text" placeholder="Address" name="address" required="">
							</div>
							<div class="styled-input agile-styled-input-top">
								<input type="text" placeholder="Phone Number" name="mobile" required="">
							</div>
							<div class="styled-input agile-styled-input-top">
								<input type="text" placeholder="Place" name="city" required="">
							</div>
							<div class="styled-input agile-styled-input-top">
								<input type="text" placeholder="Pincode" name="pin" required="">
							</div>
							<div class="styled-input">
								<input type="email" placeholder="Email" name="txt_email" required="">
							</div>
							<div class="styled-input">
								<input type="password" placeholder="Password" name="txt_pwd" id="password1" required="">
							</div>
							<div class="styled-input">
								<input type="password" placeholder="Confirm Password" name="txt_pd" id="password2" required="">
							</div>
							<input type="submit" name="btnsubmit" value="Sign Up">
						</form>
						<p>
							<a href="#">By clicking register, I agree to your terms</a>
						</p>
					</div>
				</div>
			</div>
			<!-- //Modal content-->
		</div>
	</div>
	<!-- //Modal2 -->
	<!-- //signup Model -->
	<!-- //header-bot -->
	<!-- navigation -->
	<div class="ban-top">
		<div class="container">
			<div class="agileits-navi_search">
				<form action="#" method="post">
					<select id="agileinfo-nav_search" name="agileinfo_search" required="">
						<option value="">All Categories</option>
						<option value="Kitchen">Vegetables</option>
						<option value="Household">Rice</option>
						
					</select>
				</form>
			</div>
			<div class="top_nav_left">
				<nav class="navbar navbar-default">
					<div class="container-fluid">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"
							    aria-expanded="false">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse menu--shylock" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav menu__list">
								<li class="active">
									<a class="nav-stylehead" href="index.php">Home
										<span class="sr-only">(current)</span>
									</a>
								</li>
								<li class="">
									<a class="nav-stylehead" href="#">About Us</a>
								</li>
								
								
								
								<li class="">
									<a class="nav-stylehead" href="#">Contact</a>
								</li>
						
								
								
									
									<li class="dropdown">
									<a  class="fa fa-user" href="#"  data-toggle="dropdown">
										
										<?php
										 include("config.php");
											$sql=mysqli_query($con,"Select * from tbl_login l inner join tbl_register r on l.rid=r.rid where l.lid='$r'");
											while($display=mysqli_fetch_array($sql))
											{ 
												$pname=$display['name'];
												echo $pname;}
										?>


										<b class="caret"></b></a>
									</a>
									<ul class="dropdown-menu agile_short_dropdown">
									<li>
											<a href="profile.php">Profile</a>
										</li>
									<li>
											<a href="changepassword.php">Change Password</a>
										</li>
										<li>
											<a href="logout.php">Logout</a>
										</li>
										
									</ul>
								</li>
							</ul>
						</div>
					</div>
				</nav>
			</div>
		</div>
	</div>
	<!-- //navigation -->
	<!-- banner -->
	<div id="myCarousel" class="carousel slide" data-ride="carousel">
		<!-- Indicators-->
		<ol class="carousel-indicators">
			<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
			<li data-target="#myCarousel" data-slide-to="1" class=""></li>
			<li data-target="#myCarousel" data-slide-to="2" class=""></li>
			<li data-target="#myCarousel" data-slide-to="3" class=""></li>
		</ol>
		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<div class="container">
					<div class="carousel-caption">
						<h3>Big
							<span>Save</span>
						</h3>
						<p>Get flat
							<span>10%</span> Cashback</p>
						<a class="button2" href="#">Shop Now </a>
					</div>
				</div>
			</div>
			<div class="item item2">
				<div class="container">
					<div class="carousel-caption">
						<h3>Healthy
							<span>Saving</span>
						</h3>
						<p>Get Upto
							<span>30%</span> Off</p>
						<a class="button2" href="#">Shop Now </a>
					</div>
				</div>
			</div>
			<div class="item item3">
				<div class="container">
					<div class="carousel-caption">
						<h3>Big
							<span>Deal</span>
						</h3>
						<p>Get Best Offer Upto
							<span>20%</span>
						</p>
						<a class="button2" href="#">Shop Now </a>
					</div>
				</div>
			</div>
			<div class="item item4">
				<div class="container">
					<div class="carousel-caption">
						<h3>Today
							<span>Discount</span>
						</h3>
						<p>Get Now
							<span>40%</span> Discount</p>
						<a class="button2" href="#">Shop Now </a>
					</div>
				</div>
			</div>
		</div>
		<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		</a>
		<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
			<span class="sr-only">Next</span>
		</a>
	</div>
	<!-- //banner -->

	<!-- top Products -->
	<div class="ads-grid">
		<div class="container">
			<!-- tittle heading -->
			<h3 class="tittle-w3l">Our Top Products
				<span class="heading-style">
					<i></i>
					<i></i>
					<i></i>
				</span>
			</h3>
			<!-- //tittle heading -->
			<!-- product left -->
			<!-- product left -->
			<div class="side-bar col-md-3">
				<div class="search-hotel">
					<h3 class="agileits-sear-head">	Filter Products</h3>
					<form action="#" method="GET">
						<!-- <input type="search" placeholder="Product name..." name="search" required=""> -->
						<!-- <button style="color:white; background-color:#1accfd;">search</button> -->
						<!-- <input type="submit"  value=""> -->
					
				</div></br>
				<input type="submit"  value="Search" style="color:white; background-color:#1accfd; border:none; width:80px; height:30px; align:center;">
				<!-- price range -->
				<!-- <div class="range">
					<h3 class="agileits-sear-head">Price range</h3>
					<ul class="dropdown-menu6">
						<li>
							<div id="slider-range"></div>
							<input type="text" id="amount" style="border: 0; color: #ffffff; font-weight: normal;" />
						</li>
					</ul>
				</div> -->
				<!-- //price range -->
				<!-- food preference -->
				<div class="left-side">
					<h3 class="agileits-sear-head">Category</h3>
					<ul>
						<!-- <li>
							<input type="checkbox" class="checked">
							<span class="span">Vegetable</span>
						</li>
						<li>
							<input type="checkbox" class="checked">
							<span class="span">Fruits</span>
						</li>
						<li>
							<input type="checkbox" class="checked">
							<span class="span">Grocery</span>
						</li> -->
						<?php
						$con=mysqli_connect("localhost","root","","db_grocerystore");
						$brand_query="SELECT * FROM tbl_subcategory";
						$brand_query_run=mysqli_query($con,$brand_query);
						if(mysqli_num_rows($brand_query_run) > 0)
						{
                                   foreach($brand_query_run as $brandlist)
								   {
									  // echo $brandlist['subname'];
									  $checked=[];
									  if(isset($_GET['brands']))
									  {
										$checked=$_GET['brands'];
									  }
									  ?>

<li>
							<input type="checkbox" class="checked" name="brands[]" value="<?=$brandlist['sid']; ?>"
							<?php if(in_array($brandlist['sid'],$checked)){ echo "checked";}?>
							/>
							<?= $brandlist['subname'];?>
						</li>
									  <?php
								   }
						}
						else
						{
                            echo "No brands founds";
						}
						?>
					</ul>
				</div>
				</form>
				<!-- //food preference -->
				<!-- discounts -->
				<div class="left-side">
					<h3 class="agileits-sear-head">Products</h3>
					<ul>
						<li>
							<input type="checkbox" class="checked">
							<span class="span">5% or More</span>
						</li>
						<li>
							<input type="checkbox" class="checked">
							<span class="span">10% or More</span>
						</li>
						<li>
							<input type="checkbox" class="checked">
							<span class="span">20% or More</span>
						</li>
						<li>
							<input type="checkbox" class="checked">
							<span class="span">30% or More</span>
						</li>
						<li>
							<input type="checkbox" class="checked">
							<span class="span">50% or More</span>
						</li>
						<li>
							<input type="checkbox" class="checked">
							<span class="span">60% or More</span>
						</li>
					</ul>
				</div>
				<!-- //discounts -->
				<!-- reviews -->
				
				<!-- //reviews -->
				<!-- cuisine -->
				
				<!-- //cuisine -->
			
				<!-- //cuisine -->
				<!-- deals -->
				
				<!-- //deals -->
			</div>
			<!-- //product left -->
			<!-- product right -->
			
					<!-- first section (nuts) -->
					<div class="agileinfo-ads-display col-md-9">
					<div class="wrapper">
					<div class="product-sec1">
					<!-- code for displaying product -->
					<?php 
					include("config.php");
					if(isset($_GET['brands']))
					{
                           $brandchecked=[];
						   $brandchecked=$_GET['brands'];
						   foreach($brandchecked as $rowbrand)
						   {
                             //echo $rowbrand;
							 $select_query="select p.*,s.* from tbl_product p inner join tbl_stock s on s.stockid=p.pname where p.pstatus='0' and s.sid in ($rowbrand)";
					$result=mysqli_query($con,$select_query);
					while($row=mysqli_fetch_assoc($result)){
						$pid=$row['pid'];
						$sid=$row['stockid'];
						$pname=$row['sname'];
						$pdes=$row['pdescription'];
						$pqua=$row['quantity'];
						$pm=$row['measure'];
						$Pimg=$row['pimage'];
						$a=$row['astock'];
						$price=$row['pprice'];
						
						echo"
						
						
						
						<div class='col-md-4 product-men'>
							<div class='men-pro-item simpleCart_shelfItem'>
								<div class='men-thumb-item'>
									<img src='../Admin/photo/$Pimg' alt='' height='150' width='150'>
									
									
								</div>
								<div class='item-info-product '>
									<h4>
										<a href='#'>$pname</a>
									</h4>
									<div class='info-product-price'>
										<span class='item_price'>RS.$price<p>$pqua$pm</p></span>
										
									</div>
									<form action='actioncart.php' method='post'>
									<div class='snipcart-details top_brand_home_details item_add single-item hvr-outline-out'>
									
									<input type='hidden' name='pid' value='$pid' />
									<input type='hidden' name='sid' value='$sid' />
									<input type='number' name='pqua'min='1' max='$a' value='$pqua' /><br><br>
									<input type='hidden' name='price' value='$price' />
									
									<input type='submit' name='submit' value='Add to cart' class='button' />
									</div>
									</form>
								</div>
								</div>
						</div>";}
						
					}

						   }
					
					else
					{

				
					$select_query="select p.*,s.* from tbl_product p inner join tbl_stock s on s.stockid=p.pname where p.pstatus='0'";
					$result=mysqli_query($con,$select_query);
					while($row=mysqli_fetch_assoc($result)){
						$pid=$row['pid'];
						$sid=$row['stockid'];
						$pname=$row['sname'];
						$pdes=$row['pdescription'];
						$pqua=$row['quantity'];
						$pm=$row['measure'];
						$Pimg=$row['pimage'];
						$a=$row['astock'];
						$price=$row['pprice'];
					
						echo"
						
						
						
						<div class='col-md-4 product-men'>
							<div class='men-pro-item simpleCart_shelfItem'>
								<div class='men-thumb-item'>
									<img src='../Admin/photo/$Pimg' alt='' height='150' width='150'>
									
									
								</div>
								<div class='item-info-product '>
									<h4>
										<a href='#'>$pname</a>
									</h4>
									<div class='info-product-price'>
										<span class='item_price'>RS.$price<p>$pqua$pm</p></span>
										
									</div>
									<form action='actioncart.php' method='post'>
									<div class='snipcart-details top_brand_home_details item_add single-item hvr-outline-out'>
									
									<input type='hidden' name='pid' value='$pid' />
									<input type='hidden' name='sid' value='$sid' />
									<input type='number' name='pqua'min='1' max='$a' value='$pqua' /><br><br>
									<input type='hidden' name='price' value='$price' />
									
									<input type='submit' name='submit' value='Add to cart' class='button' />
									</div>
									</form>
								</div>
								</div>
						</div>";}

					}
				
					?>
					
<!-- <form action='#' method='post'>
											<fieldset>
												<input type='hidden' name='cmd' value='_cart' />
												<input type='hidden' name='add' value='1' />
												<input type='hidden' name='business' value=' ' />
												<input type='hidden' name='item_name' value='$pname, $pqua$pm' />
												<input type='hidden' name='amount' value='$price' />
												<input type='hidden' name='discount_amount' value='1.00' />
												<input type='hidden' name='currency_code' value='INR' />
												<input type='hidden' name='return' value=' ' />
												<input type='hidden' name='cancel_return' value=' ' />
												<input type='submit' name='submit' value='Add to cart' class='button' />
											</fieldset>
										</form> -->
					
						
						<div class="clearfix"></div>
					</div>
					<!-- display product end -->
					<!-- //first section (nuts) -->
					<!-- second section (nuts special) -->
					

				<!-- //reviews -->
				<!-- cuisine -->

				<!-- //cuisine -->
				<!-- deals -->
				
				<!-- //deals -->
			
			<!-- //product left -->
			<!-- product right -->
			
					<!-- //first section (nuts) -->
					<!-- second section (nuts special) -->
					
					<!-- //second section (nuts special) -->
					<!-- third section (oils) -->
					
					<!-- //third section (oils) -->
					<!-- fourth section (noodles) -->
					
	<!-- //top products -->
	<!-- special offers -->
	
	<!-- //special offers -->
	<!-- newsletter -->
	
	<!-- //newsletter -->
	<!-- footer -->
	<footer>
		
			<!-- //footer third section -->
			<!-- footer fourth section (text) -->
			<div class="agile-sometext">
				<div class="sub-some">
					<h5>Online Grocery Shopping</h5>
					<p>Order online. All your favourite products from the low price online supermarket for grocery home delivery in Delhi,
						Gurgaon, Bengaluru, Mumbai and other cities in India. Lowest prices guaranteed on Patanjali, Aashirvaad, Pampers, Maggi,
						Saffola, Huggies, Fortune, Nestle, Amul, MamyPoko Pants, Surf Excel, Ariel, Vim, Haldiram's and others.</p>
				</div>
				<div class="sub-some">
					<h5>Shop online with the best deals & offers</h5>
					<p>Now Get Upto 40% Off On Everyday Essential Products Shown On The Offer Page. The range includes Grocery, Personal Care,
						Baby Care, Pet Supplies, Healthcare and Other Daily Need Products. Discount May Vary From Product To Product.</p>
				</div>
				<!-- brands -->
				<div class="sub-some">
					<h5>Popular Brands</h5>
					<ul>
						<li>
							<a href="#">Aashirvaad</a>
						</li>
						<li>
							<a href="#">Sunflower</a>
						</li>
						
					</ul>
				</div>
				<!-- //brands -->
				<!-- payment -->
				<div class="sub-some child-momu">
					<h5>Payment Method</h5>
					<ul>
						<li>
							<img src="images/pay2.png" alt="">
						</li>
						<li>
							<img src="images/pay5.png" alt="">
						</li>
						<li>
							<img src="images/pay1.png" alt="">
						</li>
						<li>
							<img src="images/pay4.png" alt="">
						</li>
						<li>
							<img src="images/pay6.png" alt="">
						</li>
						<li>
							<img src="images/pay3.png" alt="">
						</li>
						<li>
							<img src="images/pay7.png" alt="">
						</li>
						<li>
							<img src="images/pay8.png" alt="">
						</li>
						<li>
							<img src="images/pay9.png" alt="">
						</li>
					</ul>
				</div>
				<!-- //payment -->
			</div>
			<!-- //footer fourth section (text) -->
		</div>
	</footer>
	<!-- //footer -->
	<!-- copyright -->
	<div class="copy-right">
		<div class="container">
			<p>©2023 FreshShop. All rights reserved|Design by
				<a href="#"> Albina.</a>
			</p>
		</div>
	</div>
	<!-- //copyright -->

	<!-- js-files -->
	<!-- jquery -->
	<script src="js/jquery-2.1.4.min.js"></script>
	<!-- //jquery -->

	<!-- popup modal (for signin & signup)-->
	<script src="js/jquery.magnific-popup.js"></script>
	<script>
		$(document).ready(function () {
			$('.popup-with-zoom-anim').magnificPopup({
				type: 'inline',
				fixedContentPos: false,
				fixedBgPos: true,
				overflowY: 'auto',
				closeBtnInside: true,
				preloader: false,
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-zoom-in'
			});

		});
	</script>
	<!-- Large modal -->
	<!-- <script>
		$('#').modal('show');
	</script> -->
	<!-- //popup modal (for signin & signup)-->

	<!-- cart-js -->
	<script src="js/minicart.js"></script>
	<script>
		paypalm.minicartk.render(); //use only unique class names other than paypalm.minicartk.Also Replace same class name in css and minicart.min.js

		paypalm.minicartk.cart.on('checkout', function (evt) {
			var items = this.items(),
				len = items.length,
				total = 0,
				i;

			// Count the number of each item in the cart
			for (i = 0; i < len; i++) {
				total += items[i].get('quantity');
			}

			if (total < 3) {
				alert('The minimum order quantity is 3. Please add more to your shopping cart before checking out');
				evt.preventDefault();
			}
		});
	</script>
	<!-- //cart-js -->

	<!-- price range (top products) -->
	<script src="js/jquery-ui.js"></script>
	<script>
		//<![CDATA[ 
		$(window).load(function () {
			$("#slider-range").slider({
				range: true,
				min: 0,
				max: 9000,
				values: [50, 6000],
				slide: function (event, ui) {
					$("#amount").val("$" + ui.values[0] + " - $" + ui.values[1]);
				}
			});
			$("#amount").val("$" + $("#slider-range").slider("values", 0) + " - $" + $("#slider-range").slider("values", 1));

		}); //]]>
	</script>
	<!-- //price range (top products) -->

	<!-- flexisel (for special offers) -->
	<script src="js/jquery.flexisel.js"></script>
	<script>
		$(window).load(function () {
			$("#flexiselDemo1").flexisel({
				visibleItems: 3,
				animationSpeed: 1000,
				autoPlay: true,
				autoPlaySpeed: 3000,
				pauseOnHover: true,
				enableResponsiveBreakpoints: true,
				responsiveBreakpoints: {
					portrait: {
						changePoint: 480,
						visibleItems: 1
					},
					landscape: {
						changePoint: 640,
						visibleItems: 2
					},
					tablet: {
						changePoint: 768,
						visibleItems: 2
					}
				}
			});

		});
	</script>
	<!-- //flexisel (for special offers) -->

	<!-- password-script -->
	<script>
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}

		function validatePassword() {
			var pass2 = document.getElementById("password2").value;
			var pass1 = document.getElementById("password1").value;
			if (pass1 != pass2)
				document.getElementById("password2").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("password2").setCustomValidity('');
			//empty string means no validation error
		}
	</script>
	<!-- //password-script -->

	<!-- smoothscroll -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- //smoothscroll -->

	<!-- start-smooth-scrolling -->
	<script src="js/move-top.js"></script>
	<script src="js/easing.js"></script>
	<script>
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();

				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- //end-smooth-scrolling -->

	<!-- smooth-scrolling-of-move-up -->
	<script>
		$(document).ready(function () {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->

	<!-- for bootstrap working -->
	<script src="js/bootstrap.js"></script>
	<!-- //for bootstrap working -->
	<!-- //js-files -->


</body>

</html>
<?php
 }
 else
 {
	 die(header("location:../Guest/index.php"));
 }
?>