<?php
include("config.php");
session_start();
$lid=$_SESSION['lid'];
if(isset($_POST["btnsubmit"]))
{
	
    $Name=$_POST['name'];
    $Mobile=$_POST['mobile'];
   
   
    $Address=$_POST['address'];
    $Place=$_POST['city'];
    
      $sql1=mysqli_query($con,"INSERT INTO tbl_deliveryaddress(lid,name,phone,address,place,dstatus)VALUES('$lid','$Name','$Mobile','$Address','$Place','0')");
     
      
		

if($sql1)
  {
	 
echo "<script>alert('Address Added Sucessfully');window.location='checkout.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='checkout.php'</script>";
  }
}


?>
