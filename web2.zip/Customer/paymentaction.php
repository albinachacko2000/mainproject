
<?php
include("config.php");
session_start();

$lid=$_SESSION['lid'];

if(isset($_POST["submit"]))
{
 
  $result=mysqli_query($con,"UPDATE tbl_payment SET paytype='COD' where lid=$lid");
  header("location:payment.php");
    
    }

    
    
  	
?>
