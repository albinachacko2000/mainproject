<?php

session_start();
?> <?php
include("config.php");
	$LId=$_SESSION["lid"];
	$sql=mysqli_query($con,"SELECT * FROM `tbl_login` where lid='$LId'");
	$display=mysqli_fetch_array($sql);
	$curentpwd=$display["Pwd"];
	
?>
<?php
if(isset($_POST["btnsubmit"]))
{
	$enterpassword=$_POST['pd'];
	$enter=md5($_POST['pd']);
	$password=$_POST['npd'];
	$p=md5($_POST['npd']);
	$cpassword=$_POST['cpd'];
	
	if($curentpwd==$enter)
	{
		
		if($password==$cpassword)
	{
			
			$sql=mysqli_query($con,"UPDATE tbl_login SET Pwd='$p' WHERE lid='$LId'");
			if($sql)
			{
					echo "<script>alert('Password Updated Succesfully!!Plase login again!!');window.location='../Guest/index.php'</script>";
			}
		}
		else{
			echo "<script>alert('Password is not match!!');window.location='changepassword.php'</script>";
		}
	}
	else
		echo "<script>alert('Please enter current password correctlty!!');window.location='changepassword.php'</script>";
}
?>