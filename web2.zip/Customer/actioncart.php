
<?php
include("config.php");
session_start();
$lid=$_SESSION['lid'];
if(isset($_POST["submit"]))
{
  $stockid=$_POST['sid'];
 
    $pid=$_POST['pid'];
    $pqua=$_POST['pqua'];

    $price=$_POST['price'];
    $total=$pqua*$price;
    $result=mysqli_query($con,"SELECT * from tbl_stock where stockid='$stockid' ");
    $row=mysqli_fetch_array($result);
  if($row>0)
  {
    $sid=$row['stockid'];
    $astock=$row['astock']-$pqua;
    $stockout=$row['stockout']+$pqua;
          $sql = mysqli_query($con,"UPDATE tbl_stock SET astock='$astock',stockout='$stockout' WHERE stockid='$sid'");
    
    //$sql=mysqli_query($con,"INSERT INTO tbl_cart(lid,stockid,pid,qty,price,cstatus) VALUES('$lid','$stockid',$pid','$pqua','$price','0')");
    $s=mysqli_query($con,"SELECT count(*) as count FROM tbl_cart WHERE lid='$lid' AND cstatus='0' AND pid='$pid'");
    $display=mysqli_fetch_array($s);
    $m=mysqli_query($con,"SELECT qty,price,lid FROM tbl_cart WHERE lid='$lid' AND cstatus='0'AND pid='$pid'");
    $r=mysqli_fetch_array($m);
    $p=$r['qty'];
    $pt=$r['price'];
    $ta=$pt+$total;
    $t=$p+$pqua;
    if($display['count']>0)
  {

    $sql2 = mysqli_query($con,"UPDATE tbl_cart SET qty='$t',price='$ta' WHERE pid='$pid' AND lid='$lid' AND cstatus='0'");
  }
  else{
    $sql1=mysqli_query($con,"INSERT INTO tbl_cart(lid,stockid,pid,qty,price,cstatus) VALUES('$lid','$stockid','$pid','$pqua','$total','0')");
  }
}
    if($sql)
      {
       
       
       header('Location: checkout.php');
      }
    else
      {
        //echo "<script>alert('hello'".$t."'');window.location='#'</script>";	
       
       header('Location: index.php');
    
      }
    }
    
    
  	
?>
