<?php
session_start();
include("config.php");
if(isset($_GET["cid"]))
{
	$cid=$_GET["cid"];
if($cid>0)
{
	$s=mysqli_query($con,"SELECT count(*) as count FROM tbl_subcategory WHERE cid='$cid'");
  		$display=mysqli_fetch_array($s);
  		if($display['count']>0)
		{
			$_SESSION['vstatus'] = "Sry!!This category has Subcategory";
			header('Location: Category.php');
		}
		else
		{
			mysqli_query($con, "UPDATE  tbl_category set cstatus=1 where cid=$cid");
			$_SESSION['vstatus'] = "Deleted Successfully";
			header('Location: Category.php');
}
}
	
}
?>