<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/

-->


<?php session_start();
 $r= $_SESSION['lid'];
 if($r!="")
 {

?>
<!DOCTYPE html>
<head>

<title>FreshShop</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">

    <a href="index.html" class="logo">
        Admin Panel
    </a>
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars"></div>
    </div>
</div>
<!--logo end-->

<div class="nav notify-row" id="top_menu">
    <!--  notification start -->
   
</div>
<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
       
        <!-- user login dropdown start-->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <img alt="" src="images/2.png">
                <span class="username">Admin</span>
                
            </a>
            <ul class="dropdown-menu extended logout">
            <li><a href="changepd.php"><i class="fa fa-lock"></i> Change Password</a></li>
            <li><a href="logout.php"><i class="fa fa-key"></i> Log Out</a></li>
            </ul>
        </li>
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>
<!--header end-->
<!--sidebar start-->
<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a href="index.php">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                    </a>
                </li>
                
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-book"></i>
                        <span>Registration</span>
                    </a>
                    <ul class="sub">
						<li><a href="Deliveryboy.php">Delivery Boy</a></li>
						<li><a href="Category.php">Category</a></li>
                        <li><a href="subcategory.php">SubCategory</a></li>
						<li><a href="stock.php">Stock</a></li>
						<li><a href="product.php">Product</a></li>
						<li><a href="place.php">Place</a></li>
						
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-check"></i>
                        <span>Leave</span>
                    </a>
                    <ul class="sub">
						<li><a href="viewleave.php">Leave Approval</a></li>
						<li><a href="view.php">Leave View</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-eye"></i>
                        <span>View</span>
                    </a>
                    <ul class="sub">
						<li><a href="viewcustomer.php">Customer</a></li>
						
                    </ul>
                </li>
              
              
                
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class=" fa fa-bar-chart-o"></i>
                        <span>Reports</span>
                    </a>
                    <ul class="sub">
                        <li><a href="reportmember.php">Availability Stock</a></li>
                        
                    </ul>
                </li>
                
               
                
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
            <?php
                                       
                                       if(isset($_SESSION['status']))
                                       {
                                           ?>
                                          <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                 <?php echo $_SESSION['status'] ; ?>
                                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                                 </button>
                                    </div>
                                           <?php
                                           
                                           unset($_SESSION['status']);
                                       }
                                       ?>
                    <section class="panel">
                        <header class="panel-heading">
                            Delivery Boy
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form" action="../actionreg.php" method="post">
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <span id="msg" style="color:red;"></span>
                                        <input type="text" class="form-control" name="name"   placeholder="Enter Name" id="name" onkeyup="return Validstr1()">
                                    </div>
                                    <div class="form-group">
                                        <label for="phone">Phone</label>
                                        <span id="msg2" style="color:red;"></span>
                                        <input type="text" class="form-control" name="mobile"   placeholder="Enter Phone" id="phonenumber" onkeyup="return Validphone()">
                                    </div>
                                    <div class="form-group">
                                        <label for="address">Address</label>
                                        <input type="text" class="form-control" name="address"  id="address" placeholder="Enter Address" onkeyup="Validstr33();" required>
                                         <span id="msgn" style="color:red;"></span>
                        
                                      </div>
                                      <script>
                                             function Validstr33() 
                    {
                    var val = document.getElementById('address').value;
                     if (!val.match(/^[a-zA-Z ]*$/)) 
                     {
                     document.getElementById('msgn').innerHTML="Only alphabets are allowed ";
                       document.getElementById('address').value = "";
					   document.getElementById('address').style.color = "red";
                        return false;
                    }
                    document.getElementById('msgn').innerHTML=" ";
					document.getElementById('address').style.color = "green";
                   return true;
                    }
                                        </script>
                                    <div class="form-group">
                                        <label for="place">Place</label>
                                        <input type="text" class="form-control" name="city" id="place"  onkeyup="Validstrr();"  placeholder="Enter Place" required>
                                        <span id="m" style="color:red;"></span>
                                      </div>
                                    <script>
                                             function Validstrr() 
                    {
                    var val = document.getElementById('place').value;
                     if (!val.match(/^[a-zA-Z ]*$/)) 
                     {
                     document.getElementById('m').innerHTML="Only alphabets are allowed ";
                       document.getElementById('place').value = "";
					   document.getElementById('place').style.color = "red";
                        return false;
                    }
                    document.getElementById('m').innerHTML=" ";
					document.getElementById('place').style.color = "green";
                   return true;
                    }
                                        </script>
                                    <div class="form-group">
                                        <label for="pincode">Pincode</label>
                                        <input type="text" class="form-control" name="pin" placeholder="Enter Pincode" pattern="[0-9]{6}" required>
                                    </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email address</label>
                                    <span id="email1" style="color:red;"></span>
                                    <input type="email" class="form-control" name="txt_email"   placeholder="Enter email"   id="email" onkeyup="return Validateemail()">
                                </div>
                                <!-- <div class="form-group">
                                    <label for="exampleInputPassword1">Password</label>
                                    <input type="password" class="form-control" name="txt_pwd" id="password"  placeholder="Password" >
                                </div>
                                <span id="pss" style="color: red;"></span> -->
              
              <style>
                                                 /* The message box is shown when the user clicks on the password field */
                                                    #message {
                                                    display:none;
                                                    background:#fff;
                                                    color: #000;
                                                    position: relative;
                                                    padding: 20px;
                                                    margin-top: 10px;
                                                    }
                                                                        #message p {
                                                    padding: 1px 35px;
                                                    font-size: 14px;
                                                    }
                                                    /* Add a green text color and a checkmark when the requirements are right */
                                                    .valid {
                                                    color: green;
                                                    }

                                                    .valid:before {
                                                    position: relative;
                                                    left: -25px;
                                                    content: "✔";
                                                    }

                                                    /* Add a red text color and an "x" when the requirements are wrong */
                                                    .invalid {
                                                    color: red;
                                                    }

                                                    .invalid:before {
                                                    position: relative;
                                                    left: -25px;
                                                    content: "✖";
                                                    }
                                                    </style>
                                                <div id="message">
<!--                                                    <h4 style="color:rgb(249, 164, 61) ;">Password must contain the following:</h4>-->
                                                        <p id="letter" class="invalid">A lowercase letter</p>
                                                        <p id="capital" class="invalid">A capital (uppercase) letter</p>
                                                        <p id="number" class="invalid">A number</p>
                                                        <p id="length" class="invalid">Minimum 8 characters</b></p>
                                                     </div>
                                                <script>
                                        var myInput = document.getElementById("password");
                                        var letter = document.getElementById("letter");
                                        var capital = document.getElementById("capital");
                                        var number = document.getElementById("number");
                                        var length = document.getElementById("length");
                                        myInput.onfocus = function() {
                                        document.getElementById("message").style.display = "block";
                                        }
                                        myInput.onblur = function() {
                                        document.getElementById("message").style.display = "none";
                                        }
                                        // When the user starts to type something inside the password field
                                        myInput.onkeyup = function() {
                                        // Validate lowercase letters
                                        var lowerCaseLetters = /[a-z]/g;
                                        if(myInput.value.match(lowerCaseLetters)) {
                                            letter.classList.remove("invalid");
                                            letter.classList.add("valid");
                                        } else {
                                            letter.classList.remove("valid");
                                            letter.classList.add("invalid");
                                        }

                                        // Validate capital letters
                                        var upperCaseLetters = /[A-Z]/g;
                                        if(myInput.value.match(upperCaseLetters)) {
                                            capital.classList.remove("invalid");
                                            capital.classList.add("valid");
                                        } else {
                                            capital.classList.remove("valid");
                                            capital.classList.add("invalid");
                                        }

                                        // Validate numbers
                                        var numbers = /[0-9]/g;
                                        if(myInput.value.match(numbers)) {
                                            number.classList.remove("invalid");
                                            number.classList.add("valid");
                                        } else {
                                            number.classList.remove("valid");
                                            number.classList.add("invalid");
                                        }

                                        // Validate length
                                        if(myInput.value.length >= 8) {
                                            length.classList.remove("invalid");
                                            length.classList.add("valid");
                                        } else {
                                            length.classList.remove("valid");
                                            length.classList.add("invalid");
                                        }
                                        }
                                    </script>
                                <!-- <div class="form-group">
                                    <label for="exampleInputPassword2">Confirm Password</label>
                                    <span id="pass2" style="color: red;"></span>
                                    <input type="password" class="form-control" name="txt_pd" id="cpassword"  placeholder="Password"  onkeyup="return  Password1()">
                                </div> -->
                               
                               
                                <button type="submit" name="btnsubmit"class="btn btn-info">Submit</button>
                                <button type="reset" class="btn btn-info">Reset</button>
                                
                            </form>
                            </div>

                        </div>
                    </section>

            </div>
            <div class="col-lg-12">
            <?php
                                       
                                       if(isset($_SESSION['vstatus']))
                                       {
                                           ?>
                                          <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                 <?php echo $_SESSION['vstatus'] ; ?>
                                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                                 </button>
                                    </div>
                                           <?php
                                           
                                           unset($_SESSION['vstatus']);
                                       }
                                       ?>
            <section class="wrapper">
		<div class="table-agile-info">
        <form action="Deliveryboy.php" method="post">
        
 <div class="panel panel-default">
    <div class="panel-heading">
     DeliveryBoy
    </div>
    <div>
      <table class="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>
        <thead>
          <tr>
            <th data-breakpoints="xs">SLNO</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Place</th>
            <th style="color:#F00">Viewmore</th>
            <th style="color:#F00">Edit</th>
    <th style="color:#F00">Delete</th>
            
          </tr>
        </thead>
        <tbody>
          <tr data-expanded="true">
          <?php
include("config.php");
?>
<?php
$s=1;


$sql=mysqli_query($con,"SELECT * FROM tbl_register r inner join tbl_login l on r.rid=l.rid   WHERE  rstatus='0' AND lstatus='0' AND role='3'");


   while($display=mysqli_fetch_array($sql))
   {
	echo "<tr>";
	echo"<td>".$s++."</td>";
	echo "<td>".$display["name"]."</td>";
    echo "<td>".$display["phone"]."</td>";
    echo "<td>".$display["place"]."</td>";
    echo "<td><a style='color:#090' href='viewmoredeliveryboy.php?rid=".$display['rid']."'>Viewmore</a> </td>";
	echo "<td><a style='color:#090' href='editdeliveryboy.php?rid=".$display['rid']."'>Edit</a> </td>";
	echo "<td><a style='color:#090' href='deletedelivery.php?rid=".$display['rid']."'>Delete</a> </td>";
	
	echo "</tr>";
	
  }

echo "</table>";

?>

        </tbody>
      </table>
    </div>
  </div>
</form>
</div>
</section>
            </div>
        </div>
        <div class="row">
            
        </div>

        
 <!-- footer -->
		  <div class="footer">
			<div class="wthree-copyright">
			  <p>© 2022 AdminPanel. All rights reserved | Design by <a href="#">Albina</a></p>
			</div>
		  </div>
  <!-- / footer -->
</section>

<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
</script>
	<!-- //flexisel (for special offers) -->

	<!-- password-script -->
	<script>
		window.onload = function () {
			document.getElementById("password").onchange = validatePassword;
			document.getElementById("cpassword").onchange = validatePassword;
		}
		function validatePassword() {
			var pass2 = document.getElementById("password").value;
			var pass1 = document.getElementById("cpassword").value;
			if (pass1 != pass2)
				document.getElementById("cpassword").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("cpassword").setCustomValidity('');
			//empty string means no validation error
		}

		function Validstr1() 
      {
        var val = document.getElementById('name').value;
        if (!val.match(/^[A-Za-z ]*$/))
        {
          document.getElementById('msg').innerHTML="Only alphabets are allowed";
          document.getElementById('name').value = val;
          document.getElementById('name').style.color = "red";
          return false;
          flag=1;
        }
        else
        {
          document.getElementById('msg').innerHTML=" ";
          document.getElementById('name').style.color = "green";
          //return true;
        }
      }
      function Validstr2() 
      {
        var val = document.getElementById('lname').value;
        if (!val.match(/^[A-Za-z]*$/))
        {
          document.getElementById('amsg').innerHTML="Only alphabets are allowed";
          document.getElementById('name').value = val;
          document.getElementById('name').style.color = "red";
          return false;
          flag=1;
        }
        else
        {
          document.getElementById('amsg').innerHTML=" ";
          document.getElementById('name').style.color = "green";
          //return true;
        }
      }
      //username                                       
      function Validstr() 
      {
        var val = document.getElementById('username').value;
        if (!val.match(/^[A-Za-z ]*$/))
        {
          document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets are allowed";
          document.getElementById('username').value = val;
          document.getElementById('username').style.color = "red";
          return false;
          flag=1;
        }
        if(val.length<4||val.length>10)
        {
          document.getElementById('msg1').innerHTML="Username between 4 to 10 characters";
          document.getElementById('username').value = val;
          document.getElementById('username').style.color = "red";
          return false;
          flag=1;
        }
        else
        {
          document.getElementById('msg1').innerHTML=" ";
          document.getElementById('username').style.color = "green";
          //return true;
        }
      }
      //email
      function Validateemail()
      {
        var email=document.getElementById('email').value;  
        var mailformat = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/;
        if(email.length<3||email.length>40 && email!="")
        {
         document.getElementById('email1').innerHTML="Invalid Email";
         document.getElementById('email').value = email;
         document.getElementById('email').style.color = "red";
         return false;
        }
        if(!email.match(/^[\w\+\'\.-]+@[\w\'\.-]+\.[a-zA-Z]{2,}$/))
        {  
         document.getElementById('email1').innerHTML="Please enter a valid email";  
         document.getElementById('email').value = email;
         document.getElementById('email').style.color = "red";
         return false;  
        }
        else
        {
         document.getElementById('email1').innerHTML=" ";
         document.getElementById('email').style.color = "green";
          // return true;
        }
      }
      //Username
      function Validateusername()
      {
        var email=document.getElementById('uname').value;  
        var mailformat = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/;
        if(email.length<3||email.length>40 && email!="")
        {
         document.getElementById('email2').innerHTML="Invalid Email";
         document.getElementById('uname').value = email;
         document.getElementById('uname').style.color = "red";
         return false;
        }
        if(!email.match(/^[\w\+\'\.-]+@[\w\'\.-]+\.[a-zA-Z]{2,}$/))
        {  
         document.getElementById('email2').innerHTML="Please enter a valid email";  
         document.getElementById('uname').value = email;
         document.getElementById('uname').style.color = "red";
         return false;  
        }
        else
        {
         document.getElementById('email2').innerHTML=" ";
         document.getElementById('uname').style.color = "green";
          // return true;
        }
      }
      //phone
     function Validphone() 
      {
        var val = document.getElementById('phonenumber').value;
        if (!val.match(/^[6789][0-9]{9}$/) && val!="")
       {
         document.getElementById('msg2').innerHTML="Only Numbers are allowed and must contain 10 number";
         document.getElementById('phonenumber').value = val;
          return false;
        }
        else
        {
         document.getElementById('msg2').innerHTML="";
          //   return true;
        }
      }
      //password
      function Password()
      {
        var pass=document.getElementById('password1').value;
        consol.log(pass);
       //var patt= /^(?=.[0-9])(?=.[!@#$%^&])[A-Za-z0-9!@#$%^&]{7,15}$/;
       //var patt = /^[a-zA-Z0-9@#$%^&]{7,15}$/;
       var patt = /^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9])(?=.*[a-z]).{7,15}$/;
       if(!pass.match(patt))
       {
          console.log(pass);
          document.getElementById('pass').innerHTML="Password must be 7 to 15 character with number and special character ";  
          document.getElementById('password1').value = pass;
          document.getElementById('password1').style.color = "red";
          return false;  
        }
        else
        {
          console.log(pass, "Green");
          document.getElementById('pass').innerHTML=" ";
          document.getElementById('password1').style.color = "green";
         //return true;
        }
      }
      //confirmpassword
      function Password1()
      {
        var pass1=document.getElementById('password').value;
        var pass2=document.getElementById('cpassword').value;
       if(!pass1.match(pass2))
       {
         console.log(pass2);
         document.getElementById('pass2').innerHTML="Password must match";  
         document.getElementById('password').value = pass;
         document.getElementById('cpassword').style.color = "red";
         return false;  
       }
       else
       {
          console.log(pass1, "Green");
          document.getElementById('password').innerHTML=" ";
         document.getElementById('cpassword').style.color = "green";
		 document.getElementById('pass2').innerHTML="";  
          //return true;
        }
      }
      function Val()
     {
       if(Validstr1()===false || Validstr()===false || ValidateEmail()===false || Validphone()==false || Password()===false || Password1()===false)
        {
          return false;
        }
      }


      

	</script>
</body>
</html>
<?php } else { 
  	header("location:../Guest/index.php");
} ?>