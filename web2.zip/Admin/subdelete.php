<?php
session_start();
include("config.php");
if(isset($_GET["sid"]))
{
	$sid=$_GET["sid"];
	if($sid>0)
{
	$s=mysqli_query($con,"SELECT count(*) as count FROM tbl_product WHERE sid='$sid'");
  		$display=mysqli_fetch_array($s);
  		if($display['count']>0)
		{
			$_SESSION['vstatus'] = "Sry!!This Subcategory has Products";
			header('Location: subcategory.php');
		}
		else
		{
	mysqli_query($con, "UPDATE  tbl_subcategory set sstatus=1 where sid=$sid");
	$_SESSION['vstatus'] = "Deleted Successfully";
	header('Location: Subcategory.php');
}
}
}
?> 