
<?php
session_start();
include("config.php");
if(isset($_GET["pid"]))
{
	$pid=$_GET["pid"];
    
    $s=mysqli_query($con,"SELECT count(*) as count FROM tbl_product WHERE pname='$pid' and sstatus='0'");
  		$display=mysqli_fetch_array($s);
  		if($display['count']>0)
		{
			$_SESSION['vstatus'] = "Sry!!This stock is in the product details";
			header('Location: stock.php');
		}
		else {
	
    mysqli_query($con, "UPDATE  tbl_stock set sstatus=1 where stockid=$pid");
	$_SESSION['vstatus'] = "Deleted Successfully";
	header('Location: stock.php');
		}
}
?>