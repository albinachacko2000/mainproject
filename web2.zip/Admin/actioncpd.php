<?php

session_start();
?> <?php
include("config.php");
	$LId=$_SESSION["lid"];
	$sql=mysqli_query($con,"SELECT * FROM `tbl_login` where lid='$LId'");
	$display=mysqli_fetch_array($sql);
	$curentpwd=$display["Pwd"];

?>
<?php
if(isset($_POST["btnsubmit"]))
{
	$enterpassword=$_POST['pd'];
	$password=$_POST['npd'];
	$cpassword=$_POST['cpd'];
	if($curentpwd==$enterpassword)
	{
		
		if($password==$cpassword)
	{
			
			$sql=mysqli_query($con,"UPDATE tbl_login SET Pwd='$password' WHERE lid='$LId'");
			if($sql)
			{
					echo "<script>alert('Password Updated Succesfully!!Plase login again!!');window.location='../Guest/index.php'</script>";
			}
		}
		else{
			echo "<script>alert('Password is not match!!');window.location='changepd.php'</script>";
		}
	}
	else
		echo "<script>alert('Please enter current password correctlty!!');window.location='changepd.php'</script>";
}
?>