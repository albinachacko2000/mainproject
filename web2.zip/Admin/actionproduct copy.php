<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{

    $Name=$_POST['name'];
    
    $sid=$_POST['sid'];
    $des=$_POST['des'];
    $photo=$_FILES["photo"]["name"];
    $Q=$_POST['quantity'];
    $m=$_POST['measure'];
    $price=$_POST['price'];
    $s=mysqli_query($con,"SELECT count(*) as count FROM tbl_product WHERE pname='$Name' and pstatus='0'");
    $display=mysqli_fetch_array($s);
    if($display['count']>0)
  {
  echo "<script>alert('This Product name is already exist');window.location='product.php'</script>";	
  }
  
  else
  {
  if(file_exists("photo/".$photo))
  {
    
      
      header('Location: product.php');
  }
  else {
    move_uploaded_file($_FILES["photo"]["tmp_name"],"photo/".$_FILES["photo"]["name"]);
    
    $sql=mysqli_query($con,"INSERT INTO tbl_product(sid,pname,pdescription,pimage,quantity,measure,pprice,pstatus) VALUES('$sid','$Name','$des','$photo','$Q','$m','$price','0')");

  } 
    
  }
    if($sql)
    {
      $_SESSION['status'] = "Registered Successfully";
      
      header('Location: product.php');
     }
    else
     {
       $_SESSION['status']="Data not inserted\Already Exit Name Or Image";
      
      header('Location: product.php');
    
     }
    }
    
    
  	
?>
