<?php
session_start();
include("header.php");
include("config.php");
?>
<html>
<body>
<script type="text/javascript" src="css/jquery-2.1.4.min.js"></script>
<form method="POST">
  <div class="container" style="width:100%;margin-left:13%;margin-bottom: 8%;" >
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <br />
  
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">MEMBER REPORT</h2>
  <br />
  <br />
  <div class="row" style="    margin-left:5%;">
    <div class="col-md-3" style="text-align:right">
      <label>Ward Name</label>
    </div>
    <div class="col-md-3">
      <?php
$sql=mysqli_query($con,"SELECT * FROM tbl_ward");
?>
      <select name="WardName" id="WardName" class="form-control" style="width:500px;" onChange="populate()">
        <option value="0">---Select---</option>
        <?php
while($row=mysqli_fetch_array($sql))
{
?>
        <option value="<?php echo $row['WardId'] ?>"> <?php echo $row['WardName'];?> </option>
        <?php
}
?>
      </select>
      <br />
    </div>
</div>
    
    
    <div class="row" style="margin-left:5%;" > 
    <div class="row" style="margin-left:5%;" id="chkboxContainer" > 
    <div class="col-md-3" style="text-align:right">
      <label>Family Name</label>
    </div>
    <div class="col-md-3">
     
      <select name="FamilyName" id="FamilyName" class="form-control" style="width:500px;" onChange="">
        <option value="0">---Select---</option>
       
      </select>
      <br />
    </div></div>
    <br />
    <input type="submit" name="submit" value="View" class="btn btn-primary" style="margin-left: 72%;" >
  </div>
  <br />
  <?php
if(isset($_POST["submit"]))
{
	$WardName=$_POST["WardName"];
	$FamilyId=$_POST["FamilyName"];
?>
<script>
document.getElementById("WardName").value="<?php echo $WardName?>";
</script> 
  <br>
  <div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">
  
    <th>S1no</th>
    <th>Name</th>
    <th>Gender</th>
    <th>Contact</th>
    <th>Email</th>
    <th>Date of Brith</th>
    
    <?php
	$s=1;
include("config.php");
$result=mysqli_query($con,"Select * from tbl_member where FId='$FamilyId' and MemberStatus='1'");
while($display=mysqli_fetch_array($result))
   {
	echo "<tr>";
	echo"<td>".$s++."</td>";
	
	echo "<td>".$display["MemberNm"]."</td>";
	echo "<td>".$display["MGender"]."</td>";
	echo "<td>".$display["ConNo"]."</td>";
	echo "<td>".$display["MEmail"]."</td>";	
	echo "<td>".$display["MDob"]."</td>";
	echo "</tr>";
  
    }
   echo "</table>";
   ?>
  
<a href="export_member.php?cid=<?php echo $FamilyId;?>" ><input type="button" name="Export" value="Export" class="btn btn-success" style="margin-left:84%;margin-bottom:8%;"></a>
 </div>
 </br>
<?php
}
   
?>
  </table>
  </div>
  </div>
  </div>
  </div>
  </div>
  <br>
</form>
</body>
</html>
<?php
include("footer.php");
?>
<script>
  	function populate()
    {
	 
     var val=document.getElementById('WardName').value;
//alert(val);
 	 $.ajax({
		type: "POST",
		url: "getfamily.php",
		data: "id="+val,
		
		success: function(data){
		$("#chkboxContainer").html(data);	
		}
		})
		
 }
 </script>