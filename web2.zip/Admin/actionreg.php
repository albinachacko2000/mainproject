<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{
	$email=$_POST['txt_email'];
    $password=$_POST['txt_pwd'];
    $password1=$_POST['txt_pd'];
    $Name=$_POST['name'];
    $Mobile=$_POST['mobile'];
   
   
    $Address=$_POST['address'];
    $Place=$_POST['city'];
    $Pincode=$_POST['pin'];
    $s=mysqli_query($con,"SELECT count(*) as count FROM tbl_login WHERE Email='$email' AND role='3'");
  		$display=mysqli_fetch_array($s);
  		if($display['count']>0)
		{
      $_SESSION['status'] = "Already Exit";
  
      header('Location: Deliveryboy.php');
		}
		else
		{
    
    if($password!=$password1)
    {
      $_SESSION['status'] = "Password Doesnot match";
  
      header('Location: Deliveryboy.php');
    }
		else
    {
      $sql1=mysqli_query($con,"INSERT INTO tbl_register(name,phone,address,place,pincode,rstatus) VALUES('$Name','$Mobile','$Address','$Place','$Pincode','0')");
      $result=mysqli_query($con,"SELECT rid from tbl_register where phone=$Mobile");
  		$row=mysqli_fetch_array($result);
  	if($row>0)
		{
			$rid=$row["rid"];
      $sql=mysqli_query($con,"INSERT INTO tbl_login(rid,Email,Pwd,role)VALUES('$rid','$email','$password',3)");
        }
    else
    {
      echo "<script>alert('Error');window.location='Deliveryboy.php'</script>";
    }   
      
		

if($sql && $sql1)
{
  $_SESSION['status'] = "Registered Successfully";
  
  header('Location: Deliveryboy.php');
 }
else
 {
   $_SESSION['status']="Data not inserted";
  
  header('Location: Deliveryboy.php');

 }
}
}
}
?>
