
<?php
session_start();
include("config.php");
if(isset($_GET["pid"]))
{
	$pid=$_GET["pid"];
    
    
	$result= mysqli_query($con, "SELECT * FROM  tbl_product  where pid=$pid");
	$row=mysqli_fetch_assoc($result);
    unlink("photo/".$row['pimage']);
    mysqli_query($con, "UPDATE  tbl_product set pstatus=1 where pid=$pid");
	$_SESSION['vstatus'] = "Deleted Successfully";
	header('Location: product.php');
}
?>