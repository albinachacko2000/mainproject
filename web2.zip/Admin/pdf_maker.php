<?php                
require 'config.php'; 
include_once('tcpdf_6_2_13/tcpdf/tcpdf.php');

$MST_ID=$_GET['MST_ID'];

$inv_mst_query = "Select T1.sname,T1.astock,T1.stockin,T1.stockout from tbl_stock T1 where T1.stockid='$MST_ID' and T1.sstatus='0' ";             
$inv_mst_results = mysqli_query($con,$inv_mst_query);   
$count = mysqli_num_rows($inv_mst_results);  
if($count>0) 
{
	$inv_mst_data_row = mysqli_fetch_array($inv_mst_results, MYSQLI_ASSOC);

	//----- Code for generate pdf
	$pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
	$pdf->SetCreator(PDF_CREATOR);  
	//$pdf->SetTitle("Export HTML Table data to PDF using TCPDF in PHP");  
	$pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  
	$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
	$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
	$pdf->SetDefaultMonospacedFont('helvetica');  
	$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
	$pdf->SetMargins(PDF_MARGIN_LEFT, '5', PDF_MARGIN_RIGHT);  
	$pdf->setPrintHeader(false);  
	$pdf->setPrintFooter(false);  
	$pdf->SetAutoPageBreak(TRUE, 10);  
	$pdf->SetFont('helvetica', '', 12);  
	$pdf->AddPage(); //default A4
	//$pdf->AddPage('P','A5'); //when you require custome page size 
	
	$content = ''; 

	$content .= '
	<style type="text/css">
	body{
	font-size:12px;
	line-height:24px;
	font-family:"Helvetica Neue", "Helvetica", Helvetica, Arial, sans-serif;
	color:#000;
	}
	</style>    
	<table cellpadding="0" cellspacing="0" style="border:3px solid black;width:100%; ">
	<table style="width:100%;" >
	<tr><td colspan="2">&nbsp;</td></tr>
	<tr><td colspan="2" align="center" style="font-size:20px; "><b>FRESHSHOP</b></td></tr>
	<tr><td colspan="2"><b>PRODUCT NAME:  '.$inv_mst_data_row['sname'].' </b></td></tr>
    <tr><td ><b>BILL DT.: '.date("d-m-Y").'</b> </td></tr>
	<tr><td colspan="2" align="right">------------------------------------------------------------------------------------------------------------------------------</td></tr>
	<tr><td>&nbsp;</td><td align="right"><b>AMOUNT</b></td></tr>
	<tr><td colspan="2"><b>AVAILABLE STOCK:  </b></td></tr>
	<tr><td>&nbsp;</td><td align="right"><b> '.$inv_mst_data_row['astock'].'</b></td></tr>
    <tr><td colspan="2" align="right">------------------------------------------------------------------------------------------------------------------------------</td></tr>
	<tr><td colspan="2" align="right">------------------------------------------------------------------------------------------------------------------------------</td></tr>
	
	<tr><td colspan="2"><b>STOCKOUT:  </b></td></tr>
	<tr><td>&nbsp;</td><td align="right"><b> '.$inv_mst_data_row['stockout'].'</b></td></tr>
    <tr><td colspan="2" align="right">------------------------------------------------------------------------------------------------------------------------------</td></tr>
	<tr><td colspan="2" align="right">------------------------------------------------------------------------------------------------------------------------------</td></tr>
	
	<tr><td colspan="2"><b>STOCKIN:  </b></td></tr>
	<tr><td>&nbsp;</td><td align="right"><b> '.$inv_mst_data_row['stockin'].'</b></td></tr>
    <tr><td colspan="2" align="right">------------------------------------------------------------------------------------------------------------------------------</td></tr>
	</table>
</table>'; 
	// 	$total=0;
	// 	$inv_det_query = "Select T2.sname,T2.astock,T2.stockin,T2.stockout from tbl_stock T2 where T2.stockid='$MST_ID' and T2.sstatus='0'  ";
	// 	$inv_det_results = mysqli_query($con,$inv_det_query);    
	// 	while($inv_det_data_row = mysqli_fetch_array($inv_det_results, MYSQLI_ASSOC))
	// 	{	
	// 	$content .= '
	// 	  <tr class="itemrows">
	// 		  <td>
	// 			  <b>'.$inv_det_data_row['astock'].'</b>
	// 			  <br>
	// 			  <i>Write any remarks</i>
	// 		  </td>
	// 		  <td align="right"><b>
	// 			  '.$inv_det_data_row['stockin'].'
	// 		  </b></td>
	// 	  </tr>';
	// 	$total=$total+$inv_det_data_row['stockout'];
	// 	}
	// 	$content .= '<tr class="total"><td colspan="2" align="right">------------------------</td></tr>
	// 	<tr><td colspan="2" align="right"><b>GRAND&nbsp;TOTAL:&nbsp;'.$total.'</b></td></tr>
		
	// <tr><td colspan="2">&nbsp;</td></tr>
	
	// <tr><td colspan="2">&nbsp;</td></tr>
	
$pdf->writeHTML($content);

$file_location = "D:\xampp\htdocs\web\Admin\uploads"; //add your full path of your server
//$file_location = "/opt/lampp/htdocs/examples/generate_pdf/uploads/"; //for local xampp server

$datetime=date('dmY_hms');
$file_name = "INV_".$datetime.".pdf";
ob_end_clean();

if($_GET['ACTION']=='VIEW') 
{
	$pdf->Output($file_name, 'I'); // I means Inline view
} 
else if($_GET['ACTION']=='DOWNLOAD')
{
	$pdf->Output($file_name, 'D'); // D means download
}
else if($_GET['ACTION']=='UPLOAD')
{
$pdf->Output($file_location.$file_name, 'F'); // F means upload PDF file on some folder
echo "Upload successfully!!";
}

//----- End Code for generate pdf
	
}
else
{
	echo 'Record not found for PDF.';
}

?><script>
var date=new Date();
var tdate=date.getDate();
var month=date.getMonth() + 1;
if(tdate < 10)
{
tdate='0'+tdate;
} 
if(month < 10)
{
month='0' +month;
}
var year=date.getUTCFullYear();
var minDate=year+"-"+month+"-"+tdate;
document.getElementById("demo").setAttribute('min',minDate);
document.getElementById("demo1").setAttribute('min',minDate);  
</script>