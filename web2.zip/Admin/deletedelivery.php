<?php
session_start();
include("config.php");
if(isset($_GET["rid"]))
{
	$rid=$_GET["rid"];
	mysqli_query($con, "UPDATE  tbl_register set rstatus=1 where rid=$rid");
	mysqli_query($con, "UPDATE  tbl_login set lstatus=1 where rid=$rid");
	$_SESSION['vstatus'] = "Deleted Successfully";
	header('Location: Deliveryboy.php');

}
?>