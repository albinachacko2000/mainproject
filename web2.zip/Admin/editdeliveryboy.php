<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<head>
<?php
     session_start();
     $r= $_SESSION['lid'];
     if($r!="")
     {
    ?>
<title>FreshShop</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">

    <a href="index.html" class="logo">
        Admin Panel
    </a>
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars"></div>
    </div>
</div>
<!--logo end-->

<div class="nav notify-row" id="top_menu">
    <!--  notification start -->
   
</div>
<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
        <li>
            <input type="text" class="form-control search" placeholder=" Search">
        </li>
        <!-- user login dropdown start-->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <img alt="" src="images/2.png">
                <span class="username">Admin</span>
                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu extended logout">
            <li><a href="changepd.php"><i class="fa fa-lock"></i> Change Password</a></li>
            <li><a href="logout.php"><i class="fa fa-key"></i> Log Out</a></li>
            </ul>
        </li>
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>
<!--header end-->
<!--sidebar start-->
<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a href="index.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li> 
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-book"></i>
                        <span>Registration</span>
                    </a>
                    <ul class="sub">
						<li><a href="Deliveryboy.php">Delivery Boy</a></li>
						<li><a href="Category.php">Category</a></li>
            <li><a href="subcategory.php">SubCategory</a></li>
						<li><a href="stock.php">Stock</a></li>
						<li><a href="product.php">Product</a></li>
						<li><a href="place.php">Place</a></li>
                </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-check"></i>
                        <span>Leave</span></a>
                    <ul class="sub">
						<li><a href="viewleave.php">Leave Approval</a></li>
						<li><a href="view.php">Leave View</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-eye"></i>
                        <span>View</span>
                    </a>
                    <ul class="sub">
						<li><a href="viewcustomer.php">Customer</a></li>
						
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class=" fa fa-bar-chart-o"></i>
                        <span>Reports</span>
                    </a>
                    <ul class="sub">
                        <li><a href="reportmember.php">Availability Stock</a></li>
                         </ul>
                </li>   
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                           Edit Delivery Boy
                        </header>
                        <?php
include("config.php");
if(isset($_GET["rid"]))
{
	$rid=$_GET["rid"];
	$sql=mysqli_query($con,"SELECT * FROM tbl_register r INNER JOIN tbl_login l ON l.rid = r.rid WHERE r.rid='$rid'");
	$display=mysqli_fetch_array($sql);
}
?>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form" action="" method="post">
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <span id="msg" style="color:red;"></span>
                                        <input type="text" class="form-control" name="name" id="name" onkeyup="return Validstr1()"  placeholder="Enter Name" value="<?php echo $display['name'];?>" >
                                    </div>
                                    <div class="form-group">
                                        <label for="phone">Phone</label>
                                        <span id="msg2" style="color:red;"></span>
                                        <input type="text" class="form-control" name="mobile" id="phonenumber"  value="<?php echo $display['phone'];?>"  onkeyup="return Validphone()" placeholder="Enter Phone" >
                                    </div>
                                    <div class="form-group">
                                        <label for="address">Address</label>
                                        <input type="text" class="form-control" name="address" id="address" onkeyup="Validstr33();" placeholder="Enter Address" value="<?php echo $display['address'];?>">
                                        <span id="msgn" style="color:red;"></span></div>
                                        <script> 
                                        function Validstr33() 
                    {
                    var val = document.getElementById('address').value;
                     if (!val.match(/^[a-zA-Z ]*$/)) 
                     {
                     document.getElementById('msgn').innerHTML="Only alphabets are allowed ";
                       document.getElementById('address').value = "";
					   document.getElementById('address').style.color = "red";
                        return false;
                    }
                    document.getElementById('msgn').innerHTML=" ";
					document.getElementById('address').style.color = "green";
                   return true;
                    } </script>
                                    <div class="form-group">
                                        <label for="place">Place</label>
                                        <input type="text" class="form-control" name="city" id="place" onkeyup="Validstrr();" placeholder="Enter Place" value="<?php echo $display['place'];?>">
                                        <span id="m" style="color:red;"></span> </div>
                                    <script>
                                             function Validstrr() 
                    {
                    var val = document.getElementById('place').value;
                     if (!val.match(/^[a-zA-Z ]*$/)) 
                     {
                     document.getElementById('m').innerHTML="Only alphabets are allowed";
                       document.getElementById('place').value = "";
					   document.getElementById('address').style.color = "red";
                        return false;
                    }
                    document.getElementById('m').innerHTML=" ";
					document.getElementById('place').style.color = "green";
                   return true;
                    } </script>
                                    <div class="form-group">
                                        <label for="pincode">Pincode</label>
                                        <input type="text" class="form-control" name="pin" id="pin"pattern="[0-9]{6}" placeholder="Enter Pincode" value="<?php echo $display['pincode'];?>">
                                    </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email address</label>
                                    <input type="email" class="form-control" name="txt_email" id="exampleInputEmail1"  value="<?php echo $display['Email'];?>" placeholder="Enter email" disabled>
                                </div> <button type="submit" name="btnsubmit"class="btn btn-info">Submit</button>
                            </form> </div> </div>
                    </section>
                    <?php
if(isset($_POST["btnsubmit"]))
{
	$name=$_POST["name"];
	$phone=$_POST["mobile"];
    $address=$_POST["address"];
    $place=$_POST["city"];
    $pin=$_POST["pin"];
	$sql=mysqli_query($con,"UPDATE tbl_register SET name='$name',phone='$phone',address='$address',place='$place',pincode='$pin' WHERE rid='$rid'");
	if($sql)
	{
		$_SESSION['vstatus'] = "Updated Successfully";
  
        echo "<script>;window.location='Deliveryboy.php'</script>";
		
	}
}
?> </div>
            <div class="col-lg-12">
               
            </div>
        </div>
        <div class="row">
            
        </div>

        
 <!-- footer -->
		  <div class="footer">
			<div class="wthree-copyright">
			  <p>© 2022 AdminPanel. All rights reserved | Design by <a href="#">Albina</a></p>
			</div>
		  </div>
  <!-- / footer -->
</section>

<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script>
		window.onload = function () {
			document.getElementById("password").onchange = validatePassword;
			document.getElementById("cpassword").onchange = validatePassword;
		}
		function validatePassword() {
			var pass2 = document.getElementById("password").value;
			var pass1 = document.getElementById("cpassword").value;
			if (pass1 != pass2)
				document.getElementById("cpassword").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("cpassword").setCustomValidity('');
			//empty string means no validation error
		}

		function Validstr1() 
      {
        var val = document.getElementById('name').value;
        if (!val.match(/^[A-Za-z ]*$/))
        {
          document.getElementById('msg').innerHTML="Only alphabets are allowed";
          document.getElementById('name').value = val;
          document.getElementById('name').style.color = "red";
          return false;
          flag=1;
        }
        else
        {
          document.getElementById('msg').innerHTML=" ";
          document.getElementById('name').style.color = "green";
          //return true;
        }
      }
      function Validstr2() 
      {
        var val = document.getElementById('lname').value;
        if (!val.match(/^[A-Za-z]*$/))
        {
          document.getElementById('amsg').innerHTML="Only alphabets are allowed";
          document.getElementById('name').value = val;
          document.getElementById('name').style.color = "red";
          return false;
          flag=1;
        }
        else
        {
          document.getElementById('amsg').innerHTML=" ";
          document.getElementById('name').style.color = "green";
          //return true;
        }
      }
      //username                                       
      function Validstr() 
      {
        var val = document.getElementById('username').value;
        if (!val.match(/^[A-Za-z ]*$/))
        {
          document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets are allowed";
          document.getElementById('username').value = val;
          document.getElementById('username').style.color = "red";
          return false;
          flag=1;
        }
        if(val.length<4||val.length>10)
        {
          document.getElementById('msg1').innerHTML="Username between 4 to 10 characters";
          document.getElementById('username').value = val;
          document.getElementById('username').style.color = "red";
          return false;
          flag=1;
        }
        else
        {
          document.getElementById('msg1').innerHTML=" ";
          document.getElementById('username').style.color = "green";
          //return true;
        }
      }
      //email
      function Validateemail()
      {
        var email=document.getElementById('email').value;  
        var mailformat = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/;
        if(email.length<3||email.length>40 && email!="")
        {
         document.getElementById('email1').innerHTML="Invalid Email";
         document.getElementById('email').value = email;
         document.getElementById('email').style.color = "red";
         return false;
        }
        if(!email.match(/^[\w\+\'\.-]+@[\w\'\.-]+\.[a-zA-Z]{2,}$/))
        {  
         document.getElementById('email1').innerHTML="Please enter a valid email";  
         document.getElementById('email').value = email;
         document.getElementById('email').style.color = "red";
         return false;  
        }
        else
        {
         document.getElementById('email1').innerHTML=" ";
         document.getElementById('email').style.color = "green";
          // return true;
        }
      }
      //Username
      function Validateusername()
      {
        var email=document.getElementById('uname').value;  
        var mailformat = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/;
        if(email.length<3||email.length>40 && email!="")
        {
         document.getElementById('email2').innerHTML="Invalid Email";
         document.getElementById('uname').value = email;
         document.getElementById('uname').style.color = "red";
         return false;
        }
        if(!email.match(/^[\w\+\'\.-]+@[\w\'\.-]+\.[a-zA-Z]{2,}$/))
        {  
         document.getElementById('email2').innerHTML="Please enter a valid email";  
         document.getElementById('uname').value = email;
         document.getElementById('uname').style.color = "red";
         return false;  
        }
        else
        {
         document.getElementById('email2').innerHTML=" ";
         document.getElementById('uname').style.color = "green";
          // return true;
        }
      }
      //phone
     function Validphone() 
      {
        var val = document.getElementById('phonenumber').value;
        if (!val.match(/^[6789][0-9]{9}$/) && val!="")
       {
         document.getElementById('msg2').innerHTML="Only Numbers are allowed and must contain 10 number";
         document.getElementById('phonenumber').value = val;
          return false;
        }
        else
        {
         document.getElementById('msg2').innerHTML="";
          //   return true;
        }
      }
      //password
      function Password()
      {
        var pass=document.getElementById('password1').value;
        consol.log(pass);
       //var patt= /^(?=.[0-9])(?=.[!@#$%^&])[A-Za-z0-9!@#$%^&]{7,15}$/;
       //var patt = /^[a-zA-Z0-9@#$%^&]{7,15}$/;
       var patt = /^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9])(?=.*[a-z]).{7,15}$/;
       if(!pass.match(patt))
       {
          console.log(pass);
          document.getElementById('pass').innerHTML="Password must be 7 to 15 character with number and special character ";  
          document.getElementById('password1').value = pass;
          document.getElementById('password1').style.color = "red";
          return false;  
        }
        else
        {
          console.log(pass, "Green");
          document.getElementById('pass').innerHTML=" ";
          document.getElementById('password1').style.color = "green";
         //return true;
        }
      }
      //confirmpassword
      function Password1()
      {
        var pass1=document.getElementById('password').value;
        var pass2=document.getElementById('cpassword').value;
       if(!pass1.match(pass2))
       {
         console.log(pass2);
         document.getElementById('pass2').innerHTML="Password must match";  
         document.getElementById('password').value = pass;
         document.getElementById('cpassword').style.color = "red";
         return false;  
       }
       else
       {
          console.log(pass1, "Green");
          document.getElementById('password').innerHTML=" ";
         document.getElementById('cpassword').style.color = "green";
		 document.getElementById('pass2').innerHTML="";  
          //return true;
        }
      }
      function Val()
     {
       if(Validstr1()===false || Validstr()===false || ValidateEmail()===false || Validphone()==false || Password()===false || Password1()===false)
        {
          return false;
        }
      }


      

	</script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
<?php }  else { 
  	header("location:../Guest/index.php");
} ?>