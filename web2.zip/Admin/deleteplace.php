<?php
session_start();
include("config.php");
if(isset($_GET["pid"]))
{
	$pid=$_GET["pid"];
if($pid>0)
{

  		
			mysqli_query($con, "UPDATE  tbl_place set plstatus=1 where placeid=$pid");
			$_SESSION['vstatus'] = "Deleted Successfully";
			header('Location: place.php');
}

	
}
?>