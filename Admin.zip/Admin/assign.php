<?php

include("config.php");


if(isset($_POST["submit"]))
{
 $lId=$_POST['WardName'];
 $r=$_POST['sid'];
 //echo $lId;
// $r=$_GET['cid'];
  $sql=mysqli_query($con,"UPDATE `tbl_cart` SET `did`=$lId WHERE lid=$r AND cstatus='1'");
}

if($sql)
{
echo "<script>alert('assign job successfully');window.location='assignjob.php';</script>";
}
?>
