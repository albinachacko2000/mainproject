<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{

    $Name=$_POST['stockid'];
    
  
    $des=$_POST['des'];
    $photo=$_FILES["photo"]["name"];
    $error=$_FILES["photo"]["error"];
    $Q=$_POST['quantity'];
    
    $price=$_POST['price'];
    $s=mysqli_query($con,"SELECT count(*) as count FROM tbl_product WHERE pname='$Name' and pstatus='0'");
    $display=mysqli_fetch_array($s);
    if($display['count']>0)
  {
  echo "<script>alert('This Product name is already exist');window.location='product.php'</script>";	
  }
  
  else
  {
  if(file_exists("photo/".$photo))
  {
    
      header('Location: product.php');
  }
  else {
    
        $img=pathinfo($photo,PATHINFO_EXTENSION);
        $IMG=strtolower($img);
        $allowed=array("jpg","png","jpeg");
        if(in_array($IMG,$allowed)){
    move_uploaded_file($_FILES["photo"]["tmp_name"],"photo/".$_FILES["photo"]["name"]);
    
    $sql=mysqli_query($con,"INSERT INTO tbl_product(pname,pdescription,pimage,quantity,pprice,pstatus) VALUES('$Name','$des','$photo','$Q','$price','0')");
    if($sql)
    {
      $_SESSION['status'] = "Registered Successfully";
      
      header('Location: product.php');
     }
    else
     {
       $_SESSION['status']="Data not inserted\Already Exit Name Or Image";
      
      header('Location: product.php');
    
     }
  }else{ $_SESSION['em']="you can't upload files of this type allowed only .png, .jpg, .jpeg";
      header('Location: product.php');}
  }
  } 
    
  
    
    }
    
    
  	
?>
