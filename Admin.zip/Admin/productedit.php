<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<head>
<?php
     session_start();
     $r= $_SESSION['lid'];
     if($r!="")
     {
    ?>
<title>FreshShop</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">

    <a href="index.html" class="logo">
        Admin Panel
    </a>
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars"></div>
    </div>
</div>
<!--logo end-->

<div class="nav notify-row" id="top_menu">
    <!--  notification start -->
   
</div>
<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
        <li>
            <input type="text" class="form-control search" placeholder=" Search">
        </li>
        <!-- user login dropdown start-->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <img alt="" src="images/2.png">
                <span class="username">Admin</span>
                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu extended logout">
            <li><a href="changepd.php"><i class="fa fa-lock"></i> Change Password</a></li>
            <li><a href="logout.php"><i class="fa fa-key"></i> Log Out</a></li>
            </ul>
        </li>
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>
<!--header end-->
<!--sidebar start-->
<aside>

    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a href="index.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-book"></i>
                        <span>Registration</span>
                    </a>
                    <ul class="sub">
						<li><a href="Deliveryboy.php">Delivery Boy</a></li>
						<li><a href="Category.php">Category</a></li>
                        <li><a href="subcategory.php">SubCategory</a></li>
						<li><a href="stock.php">Stock</a></li>
						<li><a href="product.php">Product</a></li>
						<li><a href="place.php">Place</a></li>
						
                    </ul>
                </li>
				<li>
                    <a class="active" href="viewleave.php">
                        <i class="fa fa-check"></i>
                        <span>Leave Approval</span>
                    </a>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-eye"></i>
                        <span>View</span>
                    </a>
                    <ul class="sub">
						<li><a href="viewcustomer.php">Customer</a></li>
						
                    </ul>
                </li>
              
              
                
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class=" fa fa-bar-chart-o"></i>
                        <span>Reports</span>
                    </a>
                    <ul class="sub">
                        <li><a href="reportmember.php">Availability Stock</a></li>
                        
                    </ul>
                </li>
                
               
                
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
                    <section class="panel">
                    <?php
include("config.php");
if(isset($_GET["pid"]))
{
	$pid=$_GET["pid"];
	$sql=mysqli_query($con,"SELECT * FROM tbl_product  WHERE pid='$pid'");
	$display=mysqli_fetch_array($sql);
}
?>
                        <header class="panel-heading">
                            Edit Product
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form" action="" method="post" enctype="multipart/form-data">
                                  
                                    <div class="form-group">
                            <?php
$con=mysqli_connect("localhost","root","","db_grocerystore");


$sql=mysqli_query($con,"select * from tbl_stock WHERE sstatus=0"); 
?>
<label>Product Name</label><br>

     
<select   name="stockid" id="category" onchange="showResult(this.value)" class="form-control m-bot15" required >
<option value="">--select--</option>
<?php
while($row=mysqli_fetch_array($sql))
{

?>
<option value="<?php echo $row[0] ?>" ><?php echo $row[2] ?></option>

<?php
	
}
?>

</select></div>
            <div class="form-group">
                                        <label for="des">Product Description</label>
                                        <input type="text" class="form-control"  onkeyup="Validstrr();" name="des" value="<?php echo $display['pdescription'];?>"  id="des">
                                        <span id="m" style="color:red;"></span> </div>
                                        <script>
                                             function Validstrr() 
                    {
                    var val = document.getElementById('name').value;
                     if (!val.match(/^[a-zA-Z ]*$/)) 
                     {
                     document.getElementById('m').innerHTML="Only alphabets are allowed ";
                       document.getElementById('des').value = "";
					   document.getElementById('des').style.color = "red";
                        return false;
                    }
                    document.getElementById('m').innerHTML=" ";
					document.getElementById('des').style.color = "green";
                   return true;
                    }
                                        </script>
                                      <div class="form-group">           
                                        <label for="image">Product image</label>
                                        <input type="file" class="form-control" accept="image/gif, image/jpeg, image/png, image/jpg"  name="photo" id="image">
                                        <input type="hidden" class="form-control"  name="old" value="<?php echo $display['pimage'];?>" >
                                        <p>OLD IMAGE</p>
                                        <img src='photo/<?php echo $display['pimage'];?>' alt='' height='100' width='150'>
                                        <?php
                                      if(isset($_SESSION['em']))
                                       {
                                           ?>
                                          <div><p style="color:red;">
                                 <?php echo $_SESSION['em'] ; ?></p>
                                  
                                    </div>
                                           <?php
                                           
                                           unset($_SESSION['em']);
                                           
                                       }
                                       ?>     
                                    </div>
                                   
                                    <div class="panel-body">

                                   <div class="row">
                                     
                                    <div class="col-md-4 form-group">
                                    <label for="qua">Product Quantity</label>
                                <input type="number"  class="form-control" min="1" value="<?php echo $display['quantity'];?>"  name="quantity">
                                
                            </div>
                            
                          
                                
                                
                    
                            <div class="col-md-4 form-group">
                                    <label for="price">Price</label>
                                <input type="number"  min="1" class="form-control" value="<?php echo $display['pprice'];?>"  name="price">
                                
                            </div>
                            
</div>
</div>
                                <button type="submit" name="btnsubmit"class="btn btn-info">Submit</button>
                            </form>
                            </div>

                        </div>
                    </section>

            </div>
            <div class="col-lg-12">
               
            </div>
        </div>
        <div class="row">
            
        </div>
        <?php
include("config.php");

if(isset($_POST["btnsubmit"]))
{

    $Name=$_POST['stockid'];
    
    
    $des=$_POST['des'];
    $photo=$_FILES["photo"]["name"];
    $old=$_POST['old'];
    $Q=$_POST['quantity'];
    
    $price=$_POST['price'];
    if($Name!="")
{
	$s=mysqli_query($con,"SELECT count(*) as count FROM tbl_product WHERE pname='$Name'And pid!=$pid");
  		$display=mysqli_fetch_array($s);
  		if($display['count']>0)
		{
			$_SESSION['vstatus'] = "Sry!!Already Exit The Name";
            echo "<script>window.location='product.php'</script>";
		}
		else
		{
            $img=pathinfo($photo,PATHINFO_EXTENSION);
        $IMG=strtolower($img);
        $allowed=array("jpg","png","jpeg");
        if(in_array($IMG,$allowed)){
  
    move_uploaded_file($_FILES["photo"]["tmp_name"],"photo/".$_FILES["photo"]["name"]);
    
    $sql=mysqli_query($con,"UPDATE tbl_product SET pname='$Name',pdescription='$des',pimage='$photo',quantity='$Q',pprice='$price' WHERE pid='$pid'");
	if($sql)
	{
		
		$_SESSION['vstatus'] = "Updated Successfully";
  
        echo "<script>window.location='product.php'</script>";
        unlink("photo/".$old);
	}
}else{ $_SESSION['em']="you can't upload files of this type allowed only .png, .jpg, .jpeg";
    echo "<script>window.location='productedit.php'</script>";}
}
}
}
?>
        
 <!-- footer -->
		 
  <!-- / footer -->
</section>

<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>

</body>
</html>
<?php }  else { 
  	header("location:../Guest/index.php");
} ?>