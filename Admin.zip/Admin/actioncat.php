
<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{

    $Name=$_POST['name'];
    $s=mysqli_query($con,"SELECT count(*) as count FROM tbl_category WHERE cname='$Name'");
  		$display=mysqli_fetch_array($s);
  		if($display['count']>0)
		{
		echo "<script>alert('This category name is already exist');window.location='Category.php'</script>";	
		}
		else
    {
    
    $sql=mysqli_query($con,"INSERT INTO tbl_category(cname,cstatus) VALUES('$Name','0')");

    }
    
    
    if($sql)
      {
       $_SESSION['status'] = "Registered Successfully";
       
       header('Location: Category.php');
      }
    else
      {
        $_SESSION['status']="Data not inserted/Already Exit";
       
       header('Location: Category.php');
    
      }
    }
    
    
  	
?>
