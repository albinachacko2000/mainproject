<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{

    $Name=$_POST['name'];
    
    $sid=$_POST['sid'];
    
    
    $Q=$_POST['quantity'];
    $m=$_POST['measure'];
    $price=$_POST['price'];
    $s=mysqli_query($con,"SELECT count(*) as count FROM tbl_stock WHERE sname='$Name' and sstatus='0'");
    $display=mysqli_fetch_array($s);
    if($display['count']>0)
  {
  echo "<script>alert('This Product name is already exist');window.location='stock.php'</script>";	
  }
  
  else
  {
  
    
    $sql=mysqli_query($con,"INSERT INTO tbl_stock(sid,sname,stockin,astock,stockout,measure,totalamount,sstatus) VALUES('$sid','$Name','$Q','$Q','0','$m','$price','0')");
    if($sql)
    {
      $_SESSION['status'] = "Registered Successfully";
      
      header('Location: stock.php');
     }
    else
     {
       $_SESSION['status']="Data not inserted\Already Exit Name";
      
      header('Location: stock.php');
    
     }
  
  }
  } 
    
  
    
    
    
    
  	
?>
