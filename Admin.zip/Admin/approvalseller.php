<?php

include("config.php");
?>

<form action="" method="POST">

<div class="container" style="margin-left:250px;">
<?php
if(isset($_GET['id']))
{
 $lId=$_GET['id'];
  $result=mysqli_query($con,"UPDATE tbl_login SET active='1' where rid=$lId and role=4");
  
}
if($result)
{
echo "<script>alert('details has been accepted successfully. Thank you');window.location='viewseller.php';</script>";
}
?>
