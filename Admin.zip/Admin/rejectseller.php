<?php

include("config.php");
?>

<form action="" method="POST">

<div class="container" style="margin-left:250px;">
<?php
if(isset($_GET['id']))
{
 $id=$_GET['id'];
  $result=mysqli_query($con,"UPDATE tbl_login SET active='2' where rid=$lId and role=4");
  
}
if($result)
{
echo "<script>alert('details has been removed successfully. Thank you');window.location='viewleave.php';</script>";
}
?>